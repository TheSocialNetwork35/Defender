/*
 * This file is part of packetevents - https://github.com/retrooper/packetevents
 * Copyright (C) 2022 retrooper and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.github.retrooper.packetevents.event.simple;

import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.exception.PacketProcessException;
import com.github.retrooper.packetevents.manager.server.ServerVersion;
import com.github.retrooper.packetevents.netty.buffer.ByteBufHelper;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.packettype.PacketTypeCommon;
import com.github.retrooper.packetevents.protocol.player.User;
import org.jetbrains.annotations.UnknownNullability;
import org.jspecify.annotations.NullMarked;

@NullMarked
public class PacketStatusSendEvent extends PacketSendEvent {

    public PacketStatusSendEvent(
            Object channel, User user,
            @UnknownNullability Object player, Object rawByteBuf,
            boolean autoProtocolTranslation
    ) throws PacketProcessException {
        super(channel, user, player, rawByteBuf, autoProtocolTranslation);
    }

    protected PacketStatusSendEvent(
            int packetId, PacketTypeCommon packetType, ServerVersion serverVersion,
            Object channel, User user,
            @UnknownNullability Object player, Object byteBuf
    ) throws PacketProcessException {
        super(packetId, packetType, serverVersion, channel, user, player, byteBuf);
    }

    @Override
    public PacketStatusSendEvent clone() {
        Object clonedBuffer = ByteBufHelper.retainedDuplicate(getByteBuf());
        return new PacketStatusSendEvent(getPacketId(), getPacketType(), getServerVersion(),
                getChannel(), getUser(), getPlayer(), clonedBuffer);
    }


    public PacketType.Status.Server getPacketType() {
        return (PacketType.Status.Server) super.getPacketType();
    }
}
