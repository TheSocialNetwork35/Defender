//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.annotations;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.function.Function;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.incendo.cloud.meta.CommandMeta;
import org.incendo.cloud.parser.ParserParameters;

class MetaFactory implements Function<@NonNull Method, @NonNull CommandMeta> {

    private final AnnotationParser<?> annotationParser;
    private final Function<ParserParameters, CommandMeta> metaMapper;

    MetaFactory(
            final @NonNull AnnotationParser<?> annotationParser,
            final @NonNull Function<@NonNull ParserParameters, @NonNull CommandMeta> metaMapper
    ) {
        this.annotationParser = annotationParser;
        this.metaMapper = metaMapper;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public @NonNull CommandMeta apply(final @NonNull Method method) {
        final ParserParameters parameters = ParserParameters.empty();
        this.annotationParser.annotationMappers().forEach((annotationClass, mapper) -> {
            final Annotation annotation = AnnotationParser.getMethodOrClassAnnotation(method, annotationClass);
            if (annotation != null) {
                parameters.merge(((AnnotationMapper) mapper).mapAnnotation(annotation));
            }
        });
        return this.metaMapper.apply(parameters);
    }
}
