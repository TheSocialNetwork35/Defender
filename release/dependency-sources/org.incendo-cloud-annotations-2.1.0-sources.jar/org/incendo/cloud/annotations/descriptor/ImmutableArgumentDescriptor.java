//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.annotations.descriptor;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.immutables.value.Generated;
import org.incendo.cloud.component.DefaultValue;
import org.incendo.cloud.description.Description;

/**
 * Immutable implementation of {@link ArgumentDescriptor}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableArgumentDescriptor.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code ImmutableArgumentDescriptor.of()}.
 */
@Generated(from = "ArgumentDescriptor", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@API(status = API.Status.STABLE, consumers = "org.incendo.cloud.*")
public final class ImmutableArgumentDescriptor
    implements ArgumentDescriptor {
  private final @NonNull Parameter parameter;
  private final @NonNull String name;
  private final @Nullable String parserName;
  private final @Nullable String suggestions;
  private final @Nullable DefaultValue<?, ?> defaultValue;
  private final @Nullable Description description;

  private ImmutableArgumentDescriptor(
      @NonNull Parameter parameter,
      @NonNull String name,
      @Nullable String parserName,
      @Nullable String suggestions,
      @Nullable DefaultValue<?, ?> defaultValue,
      @Nullable Description description) {
    this.parameter = Objects.requireNonNull(parameter, "parameter");
    this.name = Objects.requireNonNull(name, "name");
    this.parserName = parserName;
    this.suggestions = suggestions;
    this.defaultValue = defaultValue;
    this.description = description;
  }

  private ImmutableArgumentDescriptor(
      ImmutableArgumentDescriptor original,
      @NonNull Parameter parameter,
      @NonNull String name,
      @Nullable String parserName,
      @Nullable String suggestions,
      @Nullable DefaultValue<?, ?> defaultValue,
      @Nullable Description description) {
    this.parameter = parameter;
    this.name = name;
    this.parserName = parserName;
    this.suggestions = suggestions;
    this.defaultValue = defaultValue;
    this.description = description;
  }

  /**
   * Returns the parameter.
   * @return the parameter
   */
  @Override
  public @NonNull Parameter parameter() {
    return parameter;
  }

  /**
   * Returns the argument name
   * @return the argument name
   */
  @Override
  public @NonNull String name() {
    return name;
  }

  /**
   * Returns the name of the parser to use. If {@code null} the default parser for the parameter type will be used.
   * @return the parser name, or {@code null}
   */
  @Override
  public @Nullable String parserName() {
    return parserName;
  }

  /**
   * Returns the name of the suggestion provider to use. If the string is {@code null}, the default
   * provider for the argument parser will be used. Otherwise,
   * the {@link org.incendo.cloud.parser.ParserRegistry} instance in the
   * {@link org.incendo.cloud.CommandManager} will be queried for a matching suggestion provider.
   * <p>
   * For this to work, the suggestion needs to be registered in the parser registry. To do this, use
   * {@link org.incendo.cloud.parser.ParserRegistry#registerSuggestionProvider(String, SuggestionProvider)}.
   * The registry instance can be retrieved using {@link org.incendo.cloud.CommandManager#parserRegistry()}.
   * @return the name of the suggestion provider, or {@code null}
   */
  @Override
  public @Nullable String suggestions() {
    return suggestions;
  }

  /**
   * Returns the default value.
   * @return the default value, or {@code null}
   */
  @Override
  public @Nullable DefaultValue<?, ?> defaultValue() {
    return defaultValue;
  }

  /**
   * Returns the description of the argument.
   * @return the argument description, or {@code null}
   */
  @Override
  public @Nullable Description description() {
    return description;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ArgumentDescriptor#parameter() parameter} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parameter
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableArgumentDescriptor withParameter(@NonNull Parameter value) {
    if (this.parameter == value) return this;
    @NonNull Parameter newValue = Objects.requireNonNull(value, "parameter");
    return new ImmutableArgumentDescriptor(
        this,
        newValue,
        this.name,
        this.parserName,
        this.suggestions,
        this.defaultValue,
        this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ArgumentDescriptor#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableArgumentDescriptor withName(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new ImmutableArgumentDescriptor(
        this,
        this.parameter,
        newValue,
        this.parserName,
        this.suggestions,
        this.defaultValue,
        this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ArgumentDescriptor#parserName() parserName} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parserName (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableArgumentDescriptor withParserName(@Nullable String value) {
    if (Objects.equals(this.parserName, value)) return this;
    return new ImmutableArgumentDescriptor(this, this.parameter, this.name, value, this.suggestions, this.defaultValue, this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ArgumentDescriptor#suggestions() suggestions} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for suggestions (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableArgumentDescriptor withSuggestions(@Nullable String value) {
    if (Objects.equals(this.suggestions, value)) return this;
    return new ImmutableArgumentDescriptor(this, this.parameter, this.name, this.parserName, value, this.defaultValue, this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ArgumentDescriptor#defaultValue() defaultValue} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for defaultValue (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableArgumentDescriptor withDefaultValue(@Nullable DefaultValue<?, ?> value) {
    if (this.defaultValue == value) return this;
    return new ImmutableArgumentDescriptor(this, this.parameter, this.name, this.parserName, this.suggestions, value, this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ArgumentDescriptor#description() description} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for description (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableArgumentDescriptor withDescription(@Nullable Description value) {
    if (this.description == value) return this;
    return new ImmutableArgumentDescriptor(this, this.parameter, this.name, this.parserName, this.suggestions, this.defaultValue, value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableArgumentDescriptor} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ImmutableArgumentDescriptor
        && equalsByValue((ImmutableArgumentDescriptor) another);
  }

  private boolean equalsByValue(ImmutableArgumentDescriptor another) {
    return parameter.equals(another.parameter)
        && name.equals(another.name)
        && Objects.equals(parserName, another.parserName)
        && Objects.equals(suggestions, another.suggestions)
        && Objects.equals(defaultValue, another.defaultValue)
        && Objects.equals(description, another.description);
  }

  /**
   * Computes a hash code from attributes: {@code parameter}, {@code name}, {@code parserName}, {@code suggestions}, {@code defaultValue}, {@code description}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + parameter.hashCode();
    h += (h << 5) + name.hashCode();
    h += (h << 5) + Objects.hashCode(parserName);
    h += (h << 5) + Objects.hashCode(suggestions);
    h += (h << 5) + Objects.hashCode(defaultValue);
    h += (h << 5) + Objects.hashCode(description);
    return h;
  }

  /**
   * Prints the immutable value {@code ArgumentDescriptor} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ArgumentDescriptor{"
        + "parameter=" + parameter
        + ", name=" + name
        + ", parserName=" + parserName
        + ", suggestions=" + suggestions
        + ", defaultValue=" + defaultValue
        + ", description=" + description
        + "}";
  }

  /**
   * Construct a new immutable {@code ArgumentDescriptor} instance.
   * @param parameter The value for the {@code parameter} attribute
   * @param name The value for the {@code name} attribute
   * @param parserName The value for the {@code parserName} attribute
   * @param suggestions The value for the {@code suggestions} attribute
   * @param defaultValue The value for the {@code defaultValue} attribute
   * @param description The value for the {@code description} attribute
   * @return An immutable ArgumentDescriptor instance
   */
  public static ImmutableArgumentDescriptor of(@NonNull Parameter parameter, @NonNull String name, @Nullable String parserName, @Nullable String suggestions, @Nullable DefaultValue<?, ?> defaultValue, @Nullable Description description) {
    return new ImmutableArgumentDescriptor(parameter, name, parserName, suggestions, defaultValue, description);
  }

  /**
   * Creates an immutable copy of a {@link ArgumentDescriptor} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ArgumentDescriptor instance
   */
  public static ImmutableArgumentDescriptor copyOf(ArgumentDescriptor instance) {
    if (instance instanceof ImmutableArgumentDescriptor) {
      return (ImmutableArgumentDescriptor) instance;
    }
    return ImmutableArgumentDescriptor.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableArgumentDescriptor ImmutableArgumentDescriptor}.
   * <pre>
   * ImmutableArgumentDescriptor.builder()
   *    .parameter(reflect.Parameter) // required {@link ArgumentDescriptor#parameter() parameter}
   *    .name(String) // required {@link ArgumentDescriptor#name() name}
   *    .parserName(String | null) // nullable {@link ArgumentDescriptor#parserName() parserName}
   *    .suggestions(String | null) // nullable {@link ArgumentDescriptor#suggestions() suggestions}
   *    .defaultValue(org.incendo.cloud.component.DefaultValue&lt;?, ?&gt; | null) // nullable {@link ArgumentDescriptor#defaultValue() defaultValue}
   *    .description(org.incendo.cloud.description.Description | null) // nullable {@link ArgumentDescriptor#description() description}
   *    .build();
   * </pre>
   * @return A new ImmutableArgumentDescriptor builder
   */
  public static ImmutableArgumentDescriptor.Builder builder() {
    return new ImmutableArgumentDescriptor.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableArgumentDescriptor ImmutableArgumentDescriptor}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ArgumentDescriptor", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_PARAMETER = 0x1L;
    private static final long INIT_BIT_NAME = 0x2L;
    private long initBits = 0x3L;

    private @NonNull Parameter parameter;
    private @NonNull String name;
    private @Nullable String parserName;
    private @Nullable String suggestions;
    private @Nullable DefaultValue<?, ?> defaultValue;
    private @Nullable Description description;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code org.incendo.cloud.annotations.descriptor.ArgumentDescriptor} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ArgumentDescriptor instance) {
      Objects.requireNonNull(instance, "instance");
      mergeInternal(instance);
      return this;
    }

    /**
     * Fill a builder with attribute values from the provided {@code org.incendo.cloud.annotations.descriptor.Descriptor} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(Descriptor instance) {
      Objects.requireNonNull(instance, "instance");
      mergeInternal(instance);
      return this;
    }

    private void mergeInternal(Object object) {
      @Var long bits = 0;
      if (object instanceof ArgumentDescriptor) {
        ArgumentDescriptor instance = (ArgumentDescriptor) object;
        if ((bits & 0x1L) == 0) {
          this.name(instance.name());
          bits |= 0x1L;
        }
        @Nullable Description descriptionValue = instance.description();
        if (descriptionValue != null) {
          description(descriptionValue);
        }
        @Nullable String suggestionsValue = instance.suggestions();
        if (suggestionsValue != null) {
          suggestions(suggestionsValue);
        }
        @Nullable String parserNameValue = instance.parserName();
        if (parserNameValue != null) {
          parserName(parserNameValue);
        }
        @Nullable DefaultValue<?, ?> defaultValueValue = instance.defaultValue();
        if (defaultValueValue != null) {
          defaultValue(defaultValueValue);
        }
        this.parameter(instance.parameter());
      }
      if (object instanceof Descriptor) {
        Descriptor instance = (Descriptor) object;
        if ((bits & 0x1L) == 0) {
          this.name(instance.name());
          bits |= 0x1L;
        }
      }
    }

    /**
     * Initializes the value for the {@link ArgumentDescriptor#parameter() parameter} attribute.
     * @param parameter The value for parameter 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder parameter(@NonNull Parameter parameter) {
      this.parameter = Objects.requireNonNull(parameter, "parameter");
      initBits &= ~INIT_BIT_PARAMETER;
      return this;
    }

    /**
     * Initializes the value for the {@link ArgumentDescriptor#name() name} attribute.
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(@NonNull String name) {
      this.name = Objects.requireNonNull(name, "name");
      initBits &= ~INIT_BIT_NAME;
      return this;
    }

    /**
     * Initializes the value for the {@link ArgumentDescriptor#parserName() parserName} attribute.
     * @param parserName The value for parserName (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder parserName(@Nullable String parserName) {
      this.parserName = parserName;
      return this;
    }

    /**
     * Initializes the value for the {@link ArgumentDescriptor#suggestions() suggestions} attribute.
     * @param suggestions The value for suggestions (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder suggestions(@Nullable String suggestions) {
      this.suggestions = suggestions;
      return this;
    }

    /**
     * Initializes the value for the {@link ArgumentDescriptor#defaultValue() defaultValue} attribute.
     * @param defaultValue The value for defaultValue (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder defaultValue(@Nullable DefaultValue<?, ?> defaultValue) {
      this.defaultValue = defaultValue;
      return this;
    }

    /**
     * Initializes the value for the {@link ArgumentDescriptor#description() description} attribute.
     * @param description The value for description (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder description(@Nullable Description description) {
      this.description = description;
      return this;
    }

    /**
     * Builds a new {@link ImmutableArgumentDescriptor ImmutableArgumentDescriptor}.
     * @return An immutable instance of ArgumentDescriptor
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableArgumentDescriptor build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableArgumentDescriptor(null, parameter, name, parserName, suggestions, defaultValue, description);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_PARAMETER) != 0) attributes.add("parameter");
      if ((initBits & INIT_BIT_NAME) != 0) attributes.add("name");
      return "Cannot build ArgumentDescriptor, some of required attributes are not set " + attributes;
    }
  }
}
