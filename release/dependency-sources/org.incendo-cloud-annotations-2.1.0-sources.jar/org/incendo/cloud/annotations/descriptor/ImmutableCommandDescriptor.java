//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.annotations.descriptor;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.annotations.SyntaxFragment;

/**
 * Immutable implementation of {@link CommandDescriptor}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableCommandDescriptor.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code ImmutableCommandDescriptor.of()}.
 */
@Generated(from = "CommandDescriptor", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@API(status = API.Status.STABLE, consumers = "org.incendo.cloud.*")
public final class ImmutableCommandDescriptor
    implements CommandDescriptor {
  private final @NonNull Method method;
  private final @NonNull String name;
  private final @NonNull List<SyntaxFragment> syntax;
  private final @NonNull String commandToken;
  private final @NonNull Class<?> requiredSender;

  private ImmutableCommandDescriptor(
      @NonNull Method method,
      @NonNull String name,
      Iterable<? extends SyntaxFragment> syntax,
      @NonNull String commandToken,
      @NonNull Class<?> requiredSender) {
    this.method = Objects.requireNonNull(method, "method");
    this.name = Objects.requireNonNull(name, "name");
    this.syntax = createUnmodifiableList(false, createSafeList(syntax, true, false));
    this.commandToken = Objects.requireNonNull(commandToken, "commandToken");
    this.requiredSender = Objects.requireNonNull(requiredSender, "requiredSender");
  }

  private ImmutableCommandDescriptor(ImmutableCommandDescriptor.Builder builder) {
    this.method = builder.method;
    this.syntax = builder.syntax == null ? Collections.<SyntaxFragment>emptyList() : createUnmodifiableList(true, builder.syntax);
    this.commandToken = builder.commandToken;
    this.requiredSender = builder.requiredSender;
    this.name = builder.name != null
        ? builder.name
        : Objects.requireNonNull(CommandDescriptor.super.name(), "name");
  }

  private ImmutableCommandDescriptor(
      ImmutableCommandDescriptor original,
      @NonNull Method method,
      @NonNull String name,
      @NonNull List<SyntaxFragment> syntax,
      @NonNull String commandToken,
      @NonNull Class<?> requiredSender) {
    this.method = method;
    this.name = name;
    this.syntax = syntax;
    this.commandToken = commandToken;
    this.requiredSender = requiredSender;
  }

  /**
   * Returns the command method.
   * @return the command method
   */
  @Override
  public @NonNull Method method() {
    return method;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public @NonNull String name() {
    return name;
  }

  /**
   * Returns an unmodifiable view of the syntax fragments.
   * @return the syntax fragments
   */
  @Override
  public @NonNull List<SyntaxFragment> syntax() {
    return syntax;
  }

  /**
   * Returns the root command name.
   * @return the name of the root command
   */
  @Override
  public @NonNull String commandToken() {
    return commandToken;
  }

  /**
   * Returns the required sender type.
   * @return the required sender type
   */
  @Override
  public @NonNull Class<?> requiredSender() {
    return requiredSender;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandDescriptor#method() method} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for method
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableCommandDescriptor withMethod(@NonNull Method value) {
    if (this.method == value) return this;
    @NonNull Method newValue = Objects.requireNonNull(value, "method");
    return new ImmutableCommandDescriptor(this, newValue, this.name, this.syntax, this.commandToken, this.requiredSender);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandDescriptor#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableCommandDescriptor withName(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new ImmutableCommandDescriptor(this, this.method, newValue, this.syntax, this.commandToken, this.requiredSender);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link CommandDescriptor#syntax() syntax}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutableCommandDescriptor withSyntax(SyntaxFragment... elements) {
    @NonNull List<SyntaxFragment> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new ImmutableCommandDescriptor(this, this.method, this.name, newValue, this.commandToken, this.requiredSender);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link CommandDescriptor#syntax() syntax}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of syntax elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableCommandDescriptor withSyntax(Iterable<? extends SyntaxFragment> elements) {
    if (this.syntax == elements) return this;
    @NonNull List<SyntaxFragment> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new ImmutableCommandDescriptor(this, this.method, this.name, newValue, this.commandToken, this.requiredSender);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandDescriptor#commandToken() commandToken} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandToken
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableCommandDescriptor withCommandToken(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "commandToken");
    if (this.commandToken.equals(newValue)) return this;
    return new ImmutableCommandDescriptor(this, this.method, this.name, this.syntax, newValue, this.requiredSender);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandDescriptor#requiredSender() requiredSender} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for requiredSender
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableCommandDescriptor withRequiredSender(@NonNull Class<?> value) {
    if (this.requiredSender == value) return this;
    @NonNull Class<?> newValue = Objects.requireNonNull(value, "requiredSender");
    return new ImmutableCommandDescriptor(this, this.method, this.name, this.syntax, this.commandToken, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableCommandDescriptor} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ImmutableCommandDescriptor
        && equalsByValue((ImmutableCommandDescriptor) another);
  }

  private boolean equalsByValue(ImmutableCommandDescriptor another) {
    return method.equals(another.method)
        && name.equals(another.name)
        && syntax.equals(another.syntax)
        && commandToken.equals(another.commandToken)
        && requiredSender.equals(another.requiredSender);
  }

  /**
   * Computes a hash code from attributes: {@code method}, {@code name}, {@code syntax}, {@code commandToken}, {@code requiredSender}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + method.hashCode();
    h += (h << 5) + name.hashCode();
    h += (h << 5) + syntax.hashCode();
    h += (h << 5) + commandToken.hashCode();
    h += (h << 5) + requiredSender.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandDescriptor} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandDescriptor{"
        + "method=" + method
        + ", name=" + name
        + ", syntax=" + syntax
        + ", commandToken=" + commandToken
        + ", requiredSender=" + requiredSender
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandDescriptor} instance.
   * @param method The value for the {@code method} attribute
   * @param name The value for the {@code name} attribute
   * @param syntax The value for the {@code syntax} attribute
   * @param commandToken The value for the {@code commandToken} attribute
   * @param requiredSender The value for the {@code requiredSender} attribute
   * @return An immutable CommandDescriptor instance
   */
  public static ImmutableCommandDescriptor of(@NonNull Method method, @NonNull String name, @NonNull List<SyntaxFragment> syntax, @NonNull String commandToken, @NonNull Class<?> requiredSender) {
    return of(method, name, (Iterable<? extends SyntaxFragment>) syntax, commandToken, requiredSender);
  }

  /**
   * Construct a new immutable {@code CommandDescriptor} instance.
   * @param method The value for the {@code method} attribute
   * @param name The value for the {@code name} attribute
   * @param syntax The value for the {@code syntax} attribute
   * @param commandToken The value for the {@code commandToken} attribute
   * @param requiredSender The value for the {@code requiredSender} attribute
   * @return An immutable CommandDescriptor instance
   */
  public static ImmutableCommandDescriptor of(@NonNull Method method, @NonNull String name, Iterable<? extends SyntaxFragment> syntax, @NonNull String commandToken, @NonNull Class<?> requiredSender) {
    return new ImmutableCommandDescriptor(method, name, syntax, commandToken, requiredSender);
  }

  /**
   * Creates an immutable copy of a {@link CommandDescriptor} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable CommandDescriptor instance
   */
  public static ImmutableCommandDescriptor copyOf(CommandDescriptor instance) {
    if (instance instanceof ImmutableCommandDescriptor) {
      return (ImmutableCommandDescriptor) instance;
    }
    return ImmutableCommandDescriptor.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableCommandDescriptor ImmutableCommandDescriptor}.
   * <pre>
   * ImmutableCommandDescriptor.builder()
   *    .method(reflect.Method) // required {@link CommandDescriptor#method() method}
   *    .name(String) // optional {@link CommandDescriptor#name() name}
   *    .addSyntax|addAllSyntax(org.incendo.cloud.annotations.SyntaxFragment) // {@link CommandDescriptor#syntax() syntax} elements
   *    .commandToken(String) // required {@link CommandDescriptor#commandToken() commandToken}
   *    .requiredSender(Class&lt;?&gt;) // required {@link CommandDescriptor#requiredSender() requiredSender}
   *    .build();
   * </pre>
   * @return A new ImmutableCommandDescriptor builder
   */
  public static ImmutableCommandDescriptor.Builder builder() {
    return new ImmutableCommandDescriptor.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableCommandDescriptor ImmutableCommandDescriptor}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "CommandDescriptor", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_METHOD = 0x1L;
    private static final long INIT_BIT_COMMAND_TOKEN = 0x2L;
    private static final long INIT_BIT_REQUIRED_SENDER = 0x4L;
    private long initBits = 0x7L;

    private @NonNull Method method;
    private @NonNull String name;
    private List<SyntaxFragment> syntax = null;
    private @NonNull String commandToken;
    private @NonNull Class<?> requiredSender;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code org.incendo.cloud.annotations.descriptor.CommandDescriptor} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(CommandDescriptor instance) {
      Objects.requireNonNull(instance, "instance");
      mergeInternal(instance);
      return this;
    }

    /**
     * Fill a builder with attribute values from the provided {@code org.incendo.cloud.annotations.descriptor.Descriptor} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(Descriptor instance) {
      Objects.requireNonNull(instance, "instance");
      mergeInternal(instance);
      return this;
    }

    private void mergeInternal(Object object) {
      @Var long bits = 0;
      if (object instanceof CommandDescriptor) {
        CommandDescriptor instance = (CommandDescriptor) object;
        if ((bits & 0x1L) == 0) {
          this.name(instance.name());
          bits |= 0x1L;
        }
        addAllSyntax(instance.syntax());
        this.commandToken(instance.commandToken());
        this.method(instance.method());
        this.requiredSender(instance.requiredSender());
      }
      if (object instanceof Descriptor) {
        Descriptor instance = (Descriptor) object;
        if ((bits & 0x1L) == 0) {
          this.name(instance.name());
          bits |= 0x1L;
        }
      }
    }

    /**
     * Initializes the value for the {@link CommandDescriptor#method() method} attribute.
     * @param method The value for method 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder method(@NonNull Method method) {
      this.method = Objects.requireNonNull(method, "method");
      initBits &= ~INIT_BIT_METHOD;
      return this;
    }

    /**
     * Initializes the value for the {@link CommandDescriptor#name() name} attribute.
     * <p><em>If not set, this attribute will have a default value as returned by the initializer of {@link CommandDescriptor#name() name}.</em>
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(@NonNull String name) {
      this.name = Objects.requireNonNull(name, "name");
      return this;
    }

    /**
     * Adds one element to {@link CommandDescriptor#syntax() syntax} list.
     * @param element A syntax element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addSyntax(SyntaxFragment element) {
      if (this.syntax == null) {
        this.syntax = new ArrayList<SyntaxFragment>();
      }
      this.syntax.add(Objects.requireNonNull(element, "syntax element"));
      return this;
    }

    /**
     * Adds elements to {@link CommandDescriptor#syntax() syntax} list.
     * @param elements An array of syntax elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addSyntax(SyntaxFragment... elements) {
      if (this.syntax == null) {
        this.syntax = new ArrayList<SyntaxFragment>();
      }
      for (SyntaxFragment element : elements) {
        this.syntax.add(Objects.requireNonNull(element, "syntax element"));
      }
      return this;
    }


    /**
     * Sets or replaces all elements for {@link CommandDescriptor#syntax() syntax} list.
     * @param elements An iterable of syntax elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder syntax(Iterable<? extends SyntaxFragment> elements) {
      this.syntax = new ArrayList<SyntaxFragment>();
      return addAllSyntax(elements);
    }

    /**
     * Adds elements to {@link CommandDescriptor#syntax() syntax} list.
     * @param elements An iterable of syntax elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllSyntax(Iterable<? extends SyntaxFragment> elements) {
      Objects.requireNonNull(elements, "syntax element");
      if (this.syntax == null) {
        this.syntax = new ArrayList<SyntaxFragment>();
      }
      for (SyntaxFragment element : elements) {
        this.syntax.add(Objects.requireNonNull(element, "syntax element"));
      }
      return this;
    }

    /**
     * Initializes the value for the {@link CommandDescriptor#commandToken() commandToken} attribute.
     * @param commandToken The value for commandToken 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder commandToken(@NonNull String commandToken) {
      this.commandToken = Objects.requireNonNull(commandToken, "commandToken");
      initBits &= ~INIT_BIT_COMMAND_TOKEN;
      return this;
    }

    /**
     * Initializes the value for the {@link CommandDescriptor#requiredSender() requiredSender} attribute.
     * @param requiredSender The value for requiredSender 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder requiredSender(@NonNull Class<?> requiredSender) {
      this.requiredSender = Objects.requireNonNull(requiredSender, "requiredSender");
      initBits &= ~INIT_BIT_REQUIRED_SENDER;
      return this;
    }

    /**
     * Builds a new {@link ImmutableCommandDescriptor ImmutableCommandDescriptor}.
     * @return An immutable instance of CommandDescriptor
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableCommandDescriptor build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableCommandDescriptor(this);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_METHOD) != 0) attributes.add("method");
      if ((initBits & INIT_BIT_COMMAND_TOKEN) != 0) attributes.add("commandToken");
      if ((initBits & INIT_BIT_REQUIRED_SENDER) != 0) attributes.add("requiredSender");
      return "Cannot build CommandDescriptor, some of required attributes are not set " + attributes;
    }
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>(size);
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<? extends T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
