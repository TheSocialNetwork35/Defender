//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.annotations.descriptor;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.immutables.value.Generated;
import org.incendo.cloud.description.Description;
import org.incendo.cloud.permission.Permission;

/**
 * Immutable implementation of {@link FlagDescriptor}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableFlagDescriptor.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code ImmutableFlagDescriptor.of()}.
 */
@Generated(from = "FlagDescriptor", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@API(status = API.Status.STABLE, consumers = "org.incendo.cloud.*")
public final class ImmutableFlagDescriptor implements FlagDescriptor {
  private final @NonNull Parameter parameter;
  private final @NonNull String name;
  private final @NonNull Collection<String> aliases;
  private final @Nullable String parserName;
  private final @Nullable String suggestions;
  private final @Nullable Permission permission;
  private final @Nullable Description description;
  private final boolean repeatable;

  private ImmutableFlagDescriptor(
      @NonNull Parameter parameter,
      @NonNull String name,
      @NonNull Collection<String> aliases,
      @Nullable String parserName,
      @Nullable String suggestions,
      @Nullable Permission permission,
      @Nullable Description description,
      boolean repeatable) {
    this.parameter = Objects.requireNonNull(parameter, "parameter");
    this.name = Objects.requireNonNull(name, "name");
    this.aliases = Objects.requireNonNull(aliases, "aliases");
    this.parserName = parserName;
    this.suggestions = suggestions;
    this.permission = permission;
    this.description = description;
    this.repeatable = repeatable;
  }

  private ImmutableFlagDescriptor(
      ImmutableFlagDescriptor original,
      @NonNull Parameter parameter,
      @NonNull String name,
      @NonNull Collection<String> aliases,
      @Nullable String parserName,
      @Nullable String suggestions,
      @Nullable Permission permission,
      @Nullable Description description,
      boolean repeatable) {
    this.parameter = parameter;
    this.name = name;
    this.aliases = aliases;
    this.parserName = parserName;
    this.suggestions = suggestions;
    this.permission = permission;
    this.description = description;
    this.repeatable = repeatable;
  }

  /**
   * Returns the parameter.
   * @return the parameter
   */
  @Override
  public @NonNull Parameter parameter() {
    return parameter;
  }

  /**
   * Returns the flag name.
   * @return the flag name
   */
  @Override
  public @NonNull String name() {
    return name;
  }

  /**
   * Returns an unmodifiable view of the flag aliases.
   * @return the flag aliases
   */
  @Override
  public @NonNull Collection<String> aliases() {
    return aliases;
  }

  /**
   * Returns the name of the parser to use. If {@code null} the default parser for the parameter type will be used.
   * @return the parser name, or {@code null}
   */
  @Override
  public @Nullable String parserName() {
    return parserName;
  }

  /**
   * Returns the name of the suggestion provider to use. If the string is {@code null}, the default
   * provider for the argument parser will be used. Otherwise,
   * the {@link org.incendo.cloud.parser.ParserRegistry} instance in the
   * {@link org.incendo.cloud.CommandManager} will be queried for a matching suggestion provider.
   * <p>
   * For this to work, the suggestion needs to be registered in the parser registry. To do this, use
   * {@link org.incendo.cloud.parser.ParserRegistry#registerSuggestionProvider(String, SuggestionProvider)}.
   * The registry instance can be retrieved using {@link org.incendo.cloud.CommandManager#parserRegistry()}.
   * @return the name of the suggestion provider, or {@code null}
   */
  @Override
  public @Nullable String suggestions() {
    return suggestions;
  }

  /**
   * Returns the permission of the flag.
   * @return the flag permission, or {@code null}
   */
  @Override
  public @Nullable Permission permission() {
    return permission;
  }

  /**
   * Returns the description of the flag.
   * @return the flag description, or {@code null}
   */
  @Override
  public @Nullable Description description() {
    return description;
  }

  /**
   * Returns whether the flag is repeatable.
   * @return whether the flag is repeatable
   */
  @Override
  public boolean repeatable() {
    return repeatable;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#parameter() parameter} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parameter
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withParameter(@NonNull Parameter value) {
    if (this.parameter == value) return this;
    @NonNull Parameter newValue = Objects.requireNonNull(value, "parameter");
    return new ImmutableFlagDescriptor(
        this,
        newValue,
        this.name,
        this.aliases,
        this.parserName,
        this.suggestions,
        this.permission,
        this.description,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withName(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        newValue,
        this.aliases,
        this.parserName,
        this.suggestions,
        this.permission,
        this.description,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#aliases() aliases} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for aliases
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withAliases(@NonNull Collection<String> value) {
    if (this.aliases == value) return this;
    @NonNull Collection<String> newValue = Objects.requireNonNull(value, "aliases");
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        this.name,
        newValue,
        this.parserName,
        this.suggestions,
        this.permission,
        this.description,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#parserName() parserName} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parserName (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withParserName(@Nullable String value) {
    if (Objects.equals(this.parserName, value)) return this;
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        this.name,
        this.aliases,
        value,
        this.suggestions,
        this.permission,
        this.description,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#suggestions() suggestions} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for suggestions (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withSuggestions(@Nullable String value) {
    if (Objects.equals(this.suggestions, value)) return this;
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        this.name,
        this.aliases,
        this.parserName,
        value,
        this.permission,
        this.description,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#permission() permission} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for permission (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withPermission(@Nullable Permission value) {
    if (this.permission == value) return this;
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        this.name,
        this.aliases,
        this.parserName,
        this.suggestions,
        value,
        this.description,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#description() description} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for description (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withDescription(@Nullable Description value) {
    if (this.description == value) return this;
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        this.name,
        this.aliases,
        this.parserName,
        this.suggestions,
        this.permission,
        value,
        this.repeatable);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FlagDescriptor#repeatable() repeatable} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for repeatable
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableFlagDescriptor withRepeatable(boolean value) {
    if (this.repeatable == value) return this;
    return new ImmutableFlagDescriptor(
        this,
        this.parameter,
        this.name,
        this.aliases,
        this.parserName,
        this.suggestions,
        this.permission,
        this.description,
        value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableFlagDescriptor} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ImmutableFlagDescriptor
        && equalsByValue((ImmutableFlagDescriptor) another);
  }

  private boolean equalsByValue(ImmutableFlagDescriptor another) {
    return parameter.equals(another.parameter)
        && name.equals(another.name)
        && aliases.equals(another.aliases)
        && Objects.equals(parserName, another.parserName)
        && Objects.equals(suggestions, another.suggestions)
        && Objects.equals(permission, another.permission)
        && Objects.equals(description, another.description)
        && repeatable == another.repeatable;
  }

  /**
   * Computes a hash code from attributes: {@code parameter}, {@code name}, {@code aliases}, {@code parserName}, {@code suggestions}, {@code permission}, {@code description}, {@code repeatable}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + parameter.hashCode();
    h += (h << 5) + name.hashCode();
    h += (h << 5) + aliases.hashCode();
    h += (h << 5) + Objects.hashCode(parserName);
    h += (h << 5) + Objects.hashCode(suggestions);
    h += (h << 5) + Objects.hashCode(permission);
    h += (h << 5) + Objects.hashCode(description);
    h += (h << 5) + Boolean.hashCode(repeatable);
    return h;
  }

  /**
   * Prints the immutable value {@code FlagDescriptor} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "FlagDescriptor{"
        + "parameter=" + parameter
        + ", name=" + name
        + ", aliases=" + aliases
        + ", parserName=" + parserName
        + ", suggestions=" + suggestions
        + ", permission=" + permission
        + ", description=" + description
        + ", repeatable=" + repeatable
        + "}";
  }

  /**
   * Construct a new immutable {@code FlagDescriptor} instance.
   * @param parameter The value for the {@code parameter} attribute
   * @param name The value for the {@code name} attribute
   * @param aliases The value for the {@code aliases} attribute
   * @param parserName The value for the {@code parserName} attribute
   * @param suggestions The value for the {@code suggestions} attribute
   * @param permission The value for the {@code permission} attribute
   * @param description The value for the {@code description} attribute
   * @param repeatable The value for the {@code repeatable} attribute
   * @return An immutable FlagDescriptor instance
   */
  public static ImmutableFlagDescriptor of(@NonNull Parameter parameter, @NonNull String name, @NonNull Collection<String> aliases, @Nullable String parserName, @Nullable String suggestions, @Nullable Permission permission, @Nullable Description description, boolean repeatable) {
    return new ImmutableFlagDescriptor(parameter, name, aliases, parserName, suggestions, permission, description, repeatable);
  }

  /**
   * Creates an immutable copy of a {@link FlagDescriptor} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable FlagDescriptor instance
   */
  public static ImmutableFlagDescriptor copyOf(FlagDescriptor instance) {
    if (instance instanceof ImmutableFlagDescriptor) {
      return (ImmutableFlagDescriptor) instance;
    }
    return ImmutableFlagDescriptor.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableFlagDescriptor ImmutableFlagDescriptor}.
   * <pre>
   * ImmutableFlagDescriptor.builder()
   *    .parameter(reflect.Parameter) // required {@link FlagDescriptor#parameter() parameter}
   *    .name(String) // required {@link FlagDescriptor#name() name}
   *    .aliases(Collection&lt;String&gt;) // required {@link FlagDescriptor#aliases() aliases}
   *    .parserName(String | null) // nullable {@link FlagDescriptor#parserName() parserName}
   *    .suggestions(String | null) // nullable {@link FlagDescriptor#suggestions() suggestions}
   *    .permission(org.incendo.cloud.permission.Permission | null) // nullable {@link FlagDescriptor#permission() permission}
   *    .description(org.incendo.cloud.description.Description | null) // nullable {@link FlagDescriptor#description() description}
   *    .repeatable(boolean) // required {@link FlagDescriptor#repeatable() repeatable}
   *    .build();
   * </pre>
   * @return A new ImmutableFlagDescriptor builder
   */
  public static ImmutableFlagDescriptor.Builder builder() {
    return new ImmutableFlagDescriptor.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableFlagDescriptor ImmutableFlagDescriptor}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "FlagDescriptor", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_PARAMETER = 0x1L;
    private static final long INIT_BIT_NAME = 0x2L;
    private static final long INIT_BIT_ALIASES = 0x4L;
    private static final long INIT_BIT_REPEATABLE = 0x8L;
    private long initBits = 0xfL;

    private @NonNull Parameter parameter;
    private @NonNull String name;
    private @NonNull Collection<String> aliases;
    private @Nullable String parserName;
    private @Nullable String suggestions;
    private @Nullable Permission permission;
    private @Nullable Description description;
    private boolean repeatable;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code org.incendo.cloud.annotations.descriptor.FlagDescriptor} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(FlagDescriptor instance) {
      Objects.requireNonNull(instance, "instance");
      mergeInternal(instance);
      return this;
    }

    /**
     * Fill a builder with attribute values from the provided {@code org.incendo.cloud.annotations.descriptor.Descriptor} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(Descriptor instance) {
      Objects.requireNonNull(instance, "instance");
      mergeInternal(instance);
      return this;
    }

    private void mergeInternal(Object object) {
      @Var long bits = 0;
      if (object instanceof FlagDescriptor) {
        FlagDescriptor instance = (FlagDescriptor) object;
        this.aliases(instance.aliases());
        this.repeatable(instance.repeatable());
        this.parameter(instance.parameter());
        if ((bits & 0x1L) == 0) {
          this.name(instance.name());
          bits |= 0x1L;
        }
        @Nullable Description descriptionValue = instance.description();
        if (descriptionValue != null) {
          description(descriptionValue);
        }
        @Nullable Permission permissionValue = instance.permission();
        if (permissionValue != null) {
          permission(permissionValue);
        }
        @Nullable String suggestionsValue = instance.suggestions();
        if (suggestionsValue != null) {
          suggestions(suggestionsValue);
        }
        @Nullable String parserNameValue = instance.parserName();
        if (parserNameValue != null) {
          parserName(parserNameValue);
        }
      }
      if (object instanceof Descriptor) {
        Descriptor instance = (Descriptor) object;
        if ((bits & 0x1L) == 0) {
          this.name(instance.name());
          bits |= 0x1L;
        }
      }
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#parameter() parameter} attribute.
     * @param parameter The value for parameter 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder parameter(@NonNull Parameter parameter) {
      this.parameter = Objects.requireNonNull(parameter, "parameter");
      initBits &= ~INIT_BIT_PARAMETER;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#name() name} attribute.
     * @param name The value for name 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(@NonNull String name) {
      this.name = Objects.requireNonNull(name, "name");
      initBits &= ~INIT_BIT_NAME;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#aliases() aliases} attribute.
     * @param aliases The value for aliases 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder aliases(@NonNull Collection<String> aliases) {
      this.aliases = Objects.requireNonNull(aliases, "aliases");
      initBits &= ~INIT_BIT_ALIASES;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#parserName() parserName} attribute.
     * @param parserName The value for parserName (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder parserName(@Nullable String parserName) {
      this.parserName = parserName;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#suggestions() suggestions} attribute.
     * @param suggestions The value for suggestions (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder suggestions(@Nullable String suggestions) {
      this.suggestions = suggestions;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#permission() permission} attribute.
     * @param permission The value for permission (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder permission(@Nullable Permission permission) {
      this.permission = permission;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#description() description} attribute.
     * @param description The value for description (can be {@code null})
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder description(@Nullable Description description) {
      this.description = description;
      return this;
    }

    /**
     * Initializes the value for the {@link FlagDescriptor#repeatable() repeatable} attribute.
     * @param repeatable The value for repeatable 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder repeatable(boolean repeatable) {
      this.repeatable = repeatable;
      initBits &= ~INIT_BIT_REPEATABLE;
      return this;
    }

    /**
     * Builds a new {@link ImmutableFlagDescriptor ImmutableFlagDescriptor}.
     * @return An immutable instance of FlagDescriptor
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableFlagDescriptor build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableFlagDescriptor(null, parameter, name, aliases, parserName, suggestions, permission, description, repeatable);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_PARAMETER) != 0) attributes.add("parameter");
      if ((initBits & INIT_BIT_NAME) != 0) attributes.add("name");
      if ((initBits & INIT_BIT_ALIASES) != 0) attributes.add("aliases");
      if ((initBits & INIT_BIT_REPEATABLE) != 0) attributes.add("repeatable");
      return "Cannot build FlagDescriptor, some of required attributes are not set " + attributes;
    }
  }
}
