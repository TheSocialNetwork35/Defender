//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.annotations.extractor;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.annotations.AnnotationParser;
import org.incendo.cloud.annotations.DescriptionMapper;

/**
 * Immutable implementation of {@link StandardArgumentExtractor}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableStandardArgumentExtractor.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code ImmutableStandardArgumentExtractor.of()}.
 */
@Generated(from = "StandardArgumentExtractor", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@API(status = API.Status.STABLE, consumers = "org.incendo.cloud.*")
public final class ImmutableStandardArgumentExtractor
    extends StandardArgumentExtractor {
  private final @NonNull AnnotationParser<?> annotationParser;
  private final @NonNull ParameterNameExtractor parameterNameExtractor;
  private final @NonNull DescriptionMapper descriptionMapper;

  private ImmutableStandardArgumentExtractor(
      @NonNull AnnotationParser<?> annotationParser,
      @NonNull ParameterNameExtractor parameterNameExtractor,
      @NonNull DescriptionMapper descriptionMapper) {
    this.annotationParser = Objects.requireNonNull(annotationParser, "annotationParser");
    this.parameterNameExtractor = Objects.requireNonNull(parameterNameExtractor, "parameterNameExtractor");
    this.descriptionMapper = Objects.requireNonNull(descriptionMapper, "descriptionMapper");
    this.initShim = null;
  }

  private ImmutableStandardArgumentExtractor(ImmutableStandardArgumentExtractor.Builder builder) {
    this.annotationParser = builder.annotationParser;
    if (builder.parameterNameExtractor != null) {
      initShim.parameterNameExtractor(builder.parameterNameExtractor);
    }
    if (builder.descriptionMapper != null) {
      initShim.descriptionMapper(builder.descriptionMapper);
    }
    this.parameterNameExtractor = initShim.parameterNameExtractor();
    this.descriptionMapper = initShim.descriptionMapper();
    this.initShim = null;
  }

  private ImmutableStandardArgumentExtractor(
      ImmutableStandardArgumentExtractor original,
      @NonNull AnnotationParser<?> annotationParser,
      @NonNull ParameterNameExtractor parameterNameExtractor,
      @NonNull DescriptionMapper descriptionMapper) {
    this.annotationParser = annotationParser;
    this.parameterNameExtractor = parameterNameExtractor;
    this.descriptionMapper = descriptionMapper;
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "StandardArgumentExtractor", generator = "Immutables")
  private final class InitShim {
    private byte parameterNameExtractorBuildStage = STAGE_UNINITIALIZED;
    private @NonNull ParameterNameExtractor parameterNameExtractor;

    @NonNull ParameterNameExtractor parameterNameExtractor() {
      if (parameterNameExtractorBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (parameterNameExtractorBuildStage == STAGE_UNINITIALIZED) {
        parameterNameExtractorBuildStage = STAGE_INITIALIZING;
        @NonNull ParameterNameExtractor computedValue = ImmutableStandardArgumentExtractor.super.parameterNameExtractor();
        this.parameterNameExtractor = Objects.requireNonNull(computedValue, "parameterNameExtractor");
        parameterNameExtractorBuildStage = STAGE_INITIALIZED;
      }
      return this.parameterNameExtractor;
    }

    void parameterNameExtractor(@NonNull ParameterNameExtractor parameterNameExtractor) {
      this.parameterNameExtractor = parameterNameExtractor;
      parameterNameExtractorBuildStage = STAGE_INITIALIZED;
    }

    private byte descriptionMapperBuildStage = STAGE_UNINITIALIZED;
    private @NonNull DescriptionMapper descriptionMapper;

    @NonNull DescriptionMapper descriptionMapper() {
      if (descriptionMapperBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (descriptionMapperBuildStage == STAGE_UNINITIALIZED) {
        descriptionMapperBuildStage = STAGE_INITIALIZING;
        @NonNull DescriptionMapper computedValue = ImmutableStandardArgumentExtractor.super.descriptionMapper();
        this.descriptionMapper = Objects.requireNonNull(computedValue, "descriptionMapper");
        descriptionMapperBuildStage = STAGE_INITIALIZED;
      }
      return this.descriptionMapper;
    }

    void descriptionMapper(@NonNull DescriptionMapper descriptionMapper) {
      this.descriptionMapper = descriptionMapper;
      descriptionMapperBuildStage = STAGE_INITIALIZED;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (parameterNameExtractorBuildStage == STAGE_INITIALIZING) attributes.add("parameterNameExtractor");
      if (descriptionMapperBuildStage == STAGE_INITIALIZING) attributes.add("descriptionMapper");
      return "Cannot build StandardArgumentExtractor, attribute initializers form cycle " + attributes;
    }
  }

  /**
   * Returns the annotation parser.
   * @return the annotation parser
   */
  @Override
  public @NonNull AnnotationParser<?> annotationParser() {
    return annotationParser;
  }

  /**
   * Returns the {@link ParameterNameExtractor} which is responsible for mapping parameters to syntax
   * fragments in the case that a named {@literal @Argument} annotation is not present.
   * @return the parameter name extractor
   */
  @Override
  public @NonNull ParameterNameExtractor parameterNameExtractor() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.parameterNameExtractor()
        : this.parameterNameExtractor;
  }

  /**
   * Returns the description mapper.
   * @return the description mapper
   */
  @Override
  public @NonNull DescriptionMapper descriptionMapper() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.descriptionMapper()
        : this.descriptionMapper;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link StandardArgumentExtractor#annotationParser() annotationParser} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for annotationParser
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableStandardArgumentExtractor withAnnotationParser(@NonNull AnnotationParser<?> value) {
    if (this.annotationParser == value) return this;
    @NonNull AnnotationParser<?> newValue = Objects.requireNonNull(value, "annotationParser");
    return new ImmutableStandardArgumentExtractor(this, newValue, this.parameterNameExtractor, this.descriptionMapper);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link StandardArgumentExtractor#parameterNameExtractor() parameterNameExtractor} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parameterNameExtractor
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableStandardArgumentExtractor withParameterNameExtractor(@NonNull ParameterNameExtractor value) {
    if (this.parameterNameExtractor == value) return this;
    @NonNull ParameterNameExtractor newValue = Objects.requireNonNull(value, "parameterNameExtractor");
    return new ImmutableStandardArgumentExtractor(this, this.annotationParser, newValue, this.descriptionMapper);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link StandardArgumentExtractor#descriptionMapper() descriptionMapper} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for descriptionMapper
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableStandardArgumentExtractor withDescriptionMapper(@NonNull DescriptionMapper value) {
    if (this.descriptionMapper == value) return this;
    @NonNull DescriptionMapper newValue = Objects.requireNonNull(value, "descriptionMapper");
    return new ImmutableStandardArgumentExtractor(this, this.annotationParser, this.parameterNameExtractor, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableStandardArgumentExtractor} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ImmutableStandardArgumentExtractor
        && equalsByValue((ImmutableStandardArgumentExtractor) another);
  }

  private boolean equalsByValue(ImmutableStandardArgumentExtractor another) {
    return annotationParser.equals(another.annotationParser)
        && parameterNameExtractor.equals(another.parameterNameExtractor)
        && descriptionMapper.equals(another.descriptionMapper);
  }

  /**
   * Computes a hash code from attributes: {@code annotationParser}, {@code parameterNameExtractor}, {@code descriptionMapper}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + annotationParser.hashCode();
    h += (h << 5) + parameterNameExtractor.hashCode();
    h += (h << 5) + descriptionMapper.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code StandardArgumentExtractor} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "StandardArgumentExtractor{"
        + "annotationParser=" + annotationParser
        + ", parameterNameExtractor=" + parameterNameExtractor
        + ", descriptionMapper=" + descriptionMapper
        + "}";
  }

  /**
   * Construct a new immutable {@code StandardArgumentExtractor} instance.
   * @param annotationParser The value for the {@code annotationParser} attribute
   * @param parameterNameExtractor The value for the {@code parameterNameExtractor} attribute
   * @param descriptionMapper The value for the {@code descriptionMapper} attribute
   * @return An immutable StandardArgumentExtractor instance
   */
  public static ImmutableStandardArgumentExtractor of(@NonNull AnnotationParser<?> annotationParser, @NonNull ParameterNameExtractor parameterNameExtractor, @NonNull DescriptionMapper descriptionMapper) {
    return new ImmutableStandardArgumentExtractor(annotationParser, parameterNameExtractor, descriptionMapper);
  }

  /**
   * Creates an immutable copy of a {@link StandardArgumentExtractor} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable StandardArgumentExtractor instance
   */
  public static ImmutableStandardArgumentExtractor copyOf(StandardArgumentExtractor instance) {
    if (instance instanceof ImmutableStandardArgumentExtractor) {
      return (ImmutableStandardArgumentExtractor) instance;
    }
    return ImmutableStandardArgumentExtractor.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableStandardArgumentExtractor ImmutableStandardArgumentExtractor}.
   * <pre>
   * ImmutableStandardArgumentExtractor.builder()
   *    .annotationParser(org.incendo.cloud.annotations.AnnotationParser&lt;?&gt;) // required {@link StandardArgumentExtractor#annotationParser() annotationParser}
   *    .parameterNameExtractor(org.incendo.cloud.annotations.extractor.ParameterNameExtractor) // optional {@link StandardArgumentExtractor#parameterNameExtractor() parameterNameExtractor}
   *    .descriptionMapper(org.incendo.cloud.annotations.DescriptionMapper) // optional {@link StandardArgumentExtractor#descriptionMapper() descriptionMapper}
   *    .build();
   * </pre>
   * @return A new ImmutableStandardArgumentExtractor builder
   */
  public static ImmutableStandardArgumentExtractor.Builder builder() {
    return new ImmutableStandardArgumentExtractor.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableStandardArgumentExtractor ImmutableStandardArgumentExtractor}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "StandardArgumentExtractor", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_ANNOTATION_PARSER = 0x1L;
    private long initBits = 0x1L;

    private @NonNull AnnotationParser<?> annotationParser;
    private @NonNull ParameterNameExtractor parameterNameExtractor;
    private @NonNull DescriptionMapper descriptionMapper;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code StandardArgumentExtractor} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(StandardArgumentExtractor instance) {
      Objects.requireNonNull(instance, "instance");
      this.annotationParser(instance.annotationParser());
      this.parameterNameExtractor(instance.parameterNameExtractor());
      this.descriptionMapper(instance.descriptionMapper());
      return this;
    }

    /**
     * Initializes the value for the {@link StandardArgumentExtractor#annotationParser() annotationParser} attribute.
     * @param annotationParser The value for annotationParser 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder annotationParser(@NonNull AnnotationParser<?> annotationParser) {
      this.annotationParser = Objects.requireNonNull(annotationParser, "annotationParser");
      initBits &= ~INIT_BIT_ANNOTATION_PARSER;
      return this;
    }

    /**
     * Initializes the value for the {@link StandardArgumentExtractor#parameterNameExtractor() parameterNameExtractor} attribute.
     * <p><em>If not set, this attribute will have a default value as returned by the initializer of {@link StandardArgumentExtractor#parameterNameExtractor() parameterNameExtractor}.</em>
     * @param parameterNameExtractor The value for parameterNameExtractor 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder parameterNameExtractor(@NonNull ParameterNameExtractor parameterNameExtractor) {
      this.parameterNameExtractor = Objects.requireNonNull(parameterNameExtractor, "parameterNameExtractor");
      return this;
    }

    /**
     * Initializes the value for the {@link StandardArgumentExtractor#descriptionMapper() descriptionMapper} attribute.
     * <p><em>If not set, this attribute will have a default value as returned by the initializer of {@link StandardArgumentExtractor#descriptionMapper() descriptionMapper}.</em>
     * @param descriptionMapper The value for descriptionMapper 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder descriptionMapper(@NonNull DescriptionMapper descriptionMapper) {
      this.descriptionMapper = Objects.requireNonNull(descriptionMapper, "descriptionMapper");
      return this;
    }

    /**
     * Builds a new {@link ImmutableStandardArgumentExtractor ImmutableStandardArgumentExtractor}.
     * @return An immutable instance of StandardArgumentExtractor
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableStandardArgumentExtractor build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableStandardArgumentExtractor(this);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_ANNOTATION_PARSER) != 0) attributes.add("annotationParser");
      return "Cannot build StandardArgumentExtractor, some of required attributes are not set " + attributes;
    }
  }
}
