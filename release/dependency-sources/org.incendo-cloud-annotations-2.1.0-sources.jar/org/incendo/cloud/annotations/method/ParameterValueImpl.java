//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.annotations.method;

import com.google.errorprone.annotations.Var;
import java.lang.reflect.Parameter;
import java.util.Objects;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.immutables.value.Generated;
import org.incendo.cloud.annotations.descriptor.Descriptor;

/**
 * Immutable implementation of {@link ParameterValue}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code ParameterValueImpl.of()}.
 */
@Generated(from = "ParameterValue", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class ParameterValueImpl implements ParameterValue {
  private final @NonNull Parameter parameter;
  private final @Nullable Object value;
  private final @Nullable Descriptor descriptor;

  private ParameterValueImpl(
      @NonNull Parameter parameter,
      @Nullable Object value,
      @Nullable Descriptor descriptor) {
    this.parameter = Objects.requireNonNull(parameter, "parameter");
    this.value = value;
    this.descriptor = descriptor;
  }

  private ParameterValueImpl(
      ParameterValueImpl original,
      @NonNull Parameter parameter,
      @Nullable Object value,
      @Nullable Descriptor descriptor) {
    this.parameter = parameter;
    this.value = value;
    this.descriptor = descriptor;
  }

  /**
   * @return The value of the {@code parameter} attribute
   */
  @Override
  public @NonNull Parameter parameter() {
    return parameter;
  }

  /**
   * @return The value of the {@code value} attribute
   */
  @Override
  public @Nullable Object value() {
    return value;
  }

  /**
   * @return The value of the {@code descriptor} attribute
   */
  @Override
  public @Nullable Descriptor descriptor() {
    return descriptor;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ParameterValue#parameter() parameter} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parameter
   * @return A modified copy or the {@code this} object
   */
  public final ParameterValueImpl withParameter(@NonNull Parameter value) {
    if (this.parameter == value) return this;
    @NonNull Parameter newValue = Objects.requireNonNull(value, "parameter");
    return new ParameterValueImpl(this, newValue, this.value, this.descriptor);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ParameterValue#value() value} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for value (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ParameterValueImpl withValue(@Nullable Object value) {
    if (this.value == value) return this;
    return new ParameterValueImpl(this, this.parameter, value, this.descriptor);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ParameterValue#descriptor() descriptor} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for descriptor (can be {@code null})
   * @return A modified copy or the {@code this} object
   */
  public final ParameterValueImpl withDescriptor(@Nullable Descriptor value) {
    if (this.descriptor == value) return this;
    return new ParameterValueImpl(this, this.parameter, this.value, value);
  }

  /**
   * This instance is equal to all instances of {@code ParameterValueImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ParameterValueImpl
        && equalsByValue((ParameterValueImpl) another);
  }

  private boolean equalsByValue(ParameterValueImpl another) {
    return parameter.equals(another.parameter)
        && Objects.equals(value, another.value)
        && Objects.equals(descriptor, another.descriptor);
  }

  /**
   * Computes a hash code from attributes: {@code parameter}, {@code value}, {@code descriptor}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + parameter.hashCode();
    h += (h << 5) + Objects.hashCode(value);
    h += (h << 5) + Objects.hashCode(descriptor);
    return h;
  }

  /**
   * Prints the immutable value {@code ParameterValue} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ParameterValue{"
        + "parameter=" + parameter
        + ", value=" + value
        + ", descriptor=" + descriptor
        + "}";
  }

  /**
   * Construct a new immutable {@code ParameterValue} instance.
   * @param parameter The value for the {@code parameter} attribute
   * @param value The value for the {@code value} attribute
   * @param descriptor The value for the {@code descriptor} attribute
   * @return An immutable ParameterValue instance
   */
  public static ParameterValueImpl of(@NonNull Parameter parameter, @Nullable Object value, @Nullable Descriptor descriptor) {
    return new ParameterValueImpl(parameter, value, descriptor);
  }

  /**
   * Creates an immutable copy of a {@link ParameterValue} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ParameterValue instance
   */
  public static ParameterValueImpl copyOf(ParameterValue instance) {
    if (instance instanceof ParameterValueImpl) {
      return (ParameterValueImpl) instance;
    }
    return ParameterValueImpl.of(instance.parameter(), instance.value(), instance.descriptor());
  }
}
