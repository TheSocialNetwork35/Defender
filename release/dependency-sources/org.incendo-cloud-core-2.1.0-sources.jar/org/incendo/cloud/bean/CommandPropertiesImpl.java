//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.bean;

import com.google.errorprone.annotations.Var;
import java.util.Collection;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link CommandProperties}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CommandPropertiesImpl.of()}.
 */
@Generated(from = "CommandProperties", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CommandPropertiesImpl implements CommandProperties {
  private final @NonNull String name;
  private final @NonNull Collection<String> aliases;

  private CommandPropertiesImpl(
      @NonNull String name,
      @NonNull Collection<String> aliases) {
    this.name = Objects.requireNonNull(name, "name");
    this.aliases = Objects.requireNonNull(aliases, "aliases");
  }

  private CommandPropertiesImpl(
      CommandPropertiesImpl original,
      @NonNull String name,
      @NonNull Collection<String> aliases) {
    this.name = name;
    this.aliases = aliases;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public @NonNull String name() {
    return name;
  }

  /**
   * @return The value of the {@code aliases} attribute
   */
  @Override
  public @NonNull Collection<String> aliases() {
    return aliases;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandProperties#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy or the {@code this} object
   */
  public final CommandPropertiesImpl withName(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new CommandPropertiesImpl(this, newValue, this.aliases);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandProperties#aliases() aliases} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for aliases
   * @return A modified copy or the {@code this} object
   */
  public final CommandPropertiesImpl withAliases(@NonNull Collection<String> value) {
    if (this.aliases == value) return this;
    @NonNull Collection<String> newValue = Objects.requireNonNull(value, "aliases");
    return new CommandPropertiesImpl(this, this.name, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CommandPropertiesImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CommandPropertiesImpl
        && equalsByValue((CommandPropertiesImpl) another);
  }

  private boolean equalsByValue(CommandPropertiesImpl another) {
    return name.equals(another.name)
        && aliases.equals(another.aliases);
  }

  /**
   * Computes a hash code from attributes: {@code name}, {@code aliases}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + name.hashCode();
    h += (h << 5) + aliases.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandProperties} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandProperties{"
        + "name=" + name
        + ", aliases=" + aliases
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandProperties} instance.
   * @param name The value for the {@code name} attribute
   * @param aliases The value for the {@code aliases} attribute
   * @return An immutable CommandProperties instance
   */
  public static CommandPropertiesImpl of(@NonNull String name, @NonNull Collection<String> aliases) {
    return new CommandPropertiesImpl(name, aliases);
  }

  /**
   * Creates an immutable copy of a {@link CommandProperties} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable CommandProperties instance
   */
  public static CommandPropertiesImpl copyOf(CommandProperties instance) {
    if (instance instanceof CommandPropertiesImpl) {
      return (CommandPropertiesImpl) instance;
    }
    return CommandPropertiesImpl.of(instance.name(), instance.aliases());
  }
}
