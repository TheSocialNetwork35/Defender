//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.caption;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link CaptionVariable}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CaptionVariableImpl.of()}.
 */
@Generated(from = "CaptionVariable", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CaptionVariableImpl implements CaptionVariable {
  private final @NonNull String key;
  private final @NonNull String value;

  private CaptionVariableImpl(
      @NonNull String key,
      @NonNull String value) {
    this.key = Objects.requireNonNull(key, "key");
    this.value = Objects.requireNonNull(value, "value");
  }

  private CaptionVariableImpl(
      CaptionVariableImpl original,
      @NonNull String key,
      @NonNull String value) {
    this.key = key;
    this.value = value;
  }

  /**
   * @return The value of the {@code key} attribute
   */
  @Override
  public @NonNull String key() {
    return key;
  }

  /**
   * @return The value of the {@code value} attribute
   */
  @Override
  public @NonNull String value() {
    return value;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CaptionVariable#key() key} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for key
   * @return A modified copy or the {@code this} object
   */
  public final CaptionVariableImpl withKey(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "key");
    if (this.key.equals(newValue)) return this;
    return new CaptionVariableImpl(this, newValue, this.value);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CaptionVariable#value() value} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for value
   * @return A modified copy or the {@code this} object
   */
  public final CaptionVariableImpl withValue(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "value");
    if (this.value.equals(newValue)) return this;
    return new CaptionVariableImpl(this, this.key, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CaptionVariableImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CaptionVariableImpl
        && equalsByValue((CaptionVariableImpl) another);
  }

  private boolean equalsByValue(CaptionVariableImpl another) {
    return key.equals(another.key)
        && value.equals(another.value);
  }

  /**
   * Computes a hash code from attributes: {@code key}, {@code value}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + key.hashCode();
    h += (h << 5) + value.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CaptionVariable} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CaptionVariable{"
        + "key=" + key
        + ", value=" + value
        + "}";
  }

  /**
   * Construct a new immutable {@code CaptionVariable} instance.
   * @param key The value for the {@code key} attribute
   * @param value The value for the {@code value} attribute
   * @return An immutable CaptionVariable instance
   */
  public static CaptionVariableImpl of(@NonNull String key, @NonNull String value) {
    return new CaptionVariableImpl(key, value);
  }

  /**
   * Creates an immutable copy of a {@link CaptionVariable} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable CaptionVariable instance
   */
  public static CaptionVariableImpl copyOf(CaptionVariable instance) {
    if (instance instanceof CaptionVariableImpl) {
      return (CaptionVariableImpl) instance;
    }
    return CaptionVariableImpl.of(instance.key(), instance.value());
  }
}
