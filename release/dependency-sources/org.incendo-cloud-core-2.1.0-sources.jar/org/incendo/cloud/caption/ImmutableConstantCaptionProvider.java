//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.caption;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ConstantCaptionProvider}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableConstantCaptionProvider.builder()}.
 * Use the static factory method to create immutable instances:
 * {@code ImmutableConstantCaptionProvider.of()}.
 */
@Generated(from = "ConstantCaptionProvider", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.STABLE, consumers = "org.incendo.cloud.*")
public final class ImmutableConstantCaptionProvider<C>
    extends ConstantCaptionProvider<C> {
  private final @NonNull Map<Caption, String> captions;

  private ImmutableConstantCaptionProvider(Map<? extends Caption, ? extends String> captions) {
    this.captions = createUnmodifiableMap(true, false, captions);
  }

  private ImmutableConstantCaptionProvider(
      ImmutableConstantCaptionProvider<C> original,
      @NonNull Map<Caption, String> captions) {
    this.captions = captions;
  }

  /**
   * Returns all recognized captions and their corresponding constant values.
   * @return the captions
   */
  @Override
  public @NonNull Map<Caption, String> captions() {
    return captions;
  }

  /**
   * Copy the current immutable object by replacing the {@link ConstantCaptionProvider#captions() captions} map with the specified map.
   * Nulls are not permitted as keys or values.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param entries The entries to replace the captions map
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableConstantCaptionProvider<C> withCaptions(Map<? extends Caption, ? extends String> entries) {
    if (this.captions == entries) return this;
    @NonNull Map<Caption, String> newValue = createUnmodifiableMap(true, false, entries);
    return new ImmutableConstantCaptionProvider<>(this, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableConstantCaptionProvider} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableConstantCaptionProvider<?>
        && equalsByValue((ImmutableConstantCaptionProvider<?>) another);
  }

  private boolean equalsByValue(ImmutableConstantCaptionProvider<?> another) {
    return captions.equals(another.captions);
  }

  /**
   * Computes a hash code from attributes: {@code captions}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + captions.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ConstantCaptionProvider} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ConstantCaptionProvider{"
        + "captions=" + captions
        + "}";
  }

  /**
   * Construct a new immutable {@code ConstantCaptionProvider} instance.
 * @param <C> generic parameter C
   * @param captions The value for the {@code captions} attribute
   * @return An immutable ConstantCaptionProvider instance
   */
  public static <C> ImmutableConstantCaptionProvider<C> of(Map<? extends Caption, ? extends String> captions) {
    return new ImmutableConstantCaptionProvider<>(captions);
  }

  /**
   * Creates an immutable copy of a {@link ConstantCaptionProvider} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable ConstantCaptionProvider instance
   */
  public static <C> ImmutableConstantCaptionProvider<C> copyOf(ConstantCaptionProvider<C> instance) {
    if (instance instanceof ImmutableConstantCaptionProvider<?>) {
      return (ImmutableConstantCaptionProvider<C>) instance;
    }
    return ImmutableConstantCaptionProvider.<C>builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableConstantCaptionProvider ImmutableConstantCaptionProvider}.
   * <pre>
   * ImmutableConstantCaptionProvider.&lt;C&gt;builder()
   *    .putCaption|putAllCaptions(org.incendo.cloud.caption.Caption =&gt; String) // {@link ConstantCaptionProvider#captions() captions} mappings
   *    .build();
   * </pre>
   * @param <C> generic parameter C
   * @return A new ImmutableConstantCaptionProvider builder
   */
  public static <C> ImmutableConstantCaptionProvider.Builder<C> builder() {
    return new ImmutableConstantCaptionProvider.Builder<>();
  }

  /**
   * Builds instances of type {@link ImmutableConstantCaptionProvider ImmutableConstantCaptionProvider}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ConstantCaptionProvider", generator = "Immutables")
  public static final class Builder<C> {
    private @Nullable Map<Caption, String> captions = null;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ConstantCaptionProvider} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder<C> from(ConstantCaptionProvider<C> instance) {
      Objects.requireNonNull(instance, "instance");
      putAllCaptions(instance.captions());
      return this;
    }

    /**
     * Put one entry to the {@link ConstantCaptionProvider#captions() captions} map.
     * @param key The key in the captions map
     * @param value The associated value in the captions map
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder<C> putCaption(Caption key, String value) {
      if (this.captions == null) {
        this.captions = new LinkedHashMap<Caption, String>();
      }
      this.captions.put(
          Objects.requireNonNull(key, "captions key"),
          Objects.requireNonNull(value, value == null ? "captions value for key: " + key : null));
      return this;
    }

    /**
     * Put one entry to the {@link ConstantCaptionProvider#captions() captions} map. Nulls are not permitted
     * @param entry The key and value entry
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder<C> putCaption(Map.Entry<? extends Caption, ? extends String> entry) {
      if (this.captions == null) {
        this.captions = new LinkedHashMap<Caption, String>();
      }
      Caption k = entry.getKey();
      String v = entry.getValue();
      this.captions.put(
          Objects.requireNonNull(k, "captions key"),
          Objects.requireNonNull(v, v == null ? "captions value for key: " + k : null));
      return this;
    }

    /**
     * Sets or replaces all mappings from the specified map as entries for the {@link ConstantCaptionProvider#captions() captions} map. Nulls are not permitted
     * @param entries The entries that will be added to the captions map
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder<C> captions(Map<? extends Caption, ? extends String> entries) {
      this.captions = new LinkedHashMap<Caption, String>();
      return putAllCaptions(entries);
    }

    /**
     * Put all mappings from the specified map as entries to {@link ConstantCaptionProvider#captions() captions} map. Nulls are not permitted
     * @param entries The entries that will be added to the captions map
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder<C> putAllCaptions(Map<? extends Caption, ? extends String> entries) {
      if (this.captions == null) {
        this.captions = new LinkedHashMap<Caption, String>();
      }
      for (Map.Entry<? extends Caption, ? extends String> e : entries.entrySet()) {
        Caption k = e.getKey();
        String v = e.getValue();
        this.captions.put(
            Objects.requireNonNull(k, "captions key"),
            Objects.requireNonNull(v, v == null ? "captions value for key: " + k : null));
      }
      return this;
    }

    /**
     * Builds a new {@link ImmutableConstantCaptionProvider ImmutableConstantCaptionProvider}.
     * @return An immutable instance of ConstantCaptionProvider
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableConstantCaptionProvider<C> build() {
      return new ImmutableConstantCaptionProvider<>(
          null,
          captions == null ? Collections.<Caption, String>emptyMap() : createUnmodifiableMap(false, false, captions));
    }
  }

  private static <K, V> Map<K, V> createUnmodifiableMap(boolean checkNulls, boolean skipNulls, Map<? extends K, ? extends V> map) {
    switch (map.size()) {
    case 0: return Collections.emptyMap();
    case 1: {
      Map.Entry<? extends K, ? extends V> e = map.entrySet().iterator().next();
      K k = e.getKey();
      V v = e.getValue();
      if (checkNulls) {
        Objects.requireNonNull(k, "key");
        Objects.requireNonNull(v, v == null ? "value for key: " + k : null);
      }
      if (skipNulls && (k == null || v == null)) {
        return Collections.emptyMap();
      }
      return Collections.singletonMap(k, v);
    }
    default: {
      Map<K, V> linkedMap = new LinkedHashMap<>(map.size() * 4 / 3 + 1);
      if (skipNulls || checkNulls) {
        for (Map.Entry<? extends K, ? extends V> e : map.entrySet()) {
          K k = e.getKey();
          V v = e.getValue();
          if (skipNulls) {
            if (k == null || v == null) continue;
          } else if (checkNulls) {
            Objects.requireNonNull(k, "key");
            Objects.requireNonNull(v, v == null ? "value for key: " + k : null);
          }
          linkedMap.put(k, v);
        }
      } else {
        linkedMap.putAll(map);
      }
      return Collections.unmodifiableMap(linkedMap);
    }
    }
  }
}
