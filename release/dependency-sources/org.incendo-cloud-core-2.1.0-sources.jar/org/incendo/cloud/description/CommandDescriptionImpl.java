//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.description;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link CommandDescription}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CommandDescriptionImpl.of()}.
 */
@Generated(from = "CommandDescription", generator = "Immutables")
@SuppressWarnings({"unused", "all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CommandDescriptionImpl implements CommandDescription {
  private final @NonNull Description description;
  private final @NonNull Description verboseDescription;

  private CommandDescriptionImpl(
      @NonNull Description description,
      @NonNull Description verboseDescription) {
    this.description = Objects.requireNonNull(description, "description");
    this.verboseDescription = Objects.requireNonNull(verboseDescription, "verboseDescription");
  }

  private CommandDescriptionImpl(
      CommandDescriptionImpl original,
      @NonNull Description description,
      @NonNull Description verboseDescription) {
    this.description = description;
    this.verboseDescription = verboseDescription;
  }

  /**
   * @return The value of the {@code description} attribute
   */
  @Override
  public @NonNull Description description() {
    return description;
  }

  /**
   * @return The value of the {@code verboseDescription} attribute
   */
  @Override
  public @NonNull Description verboseDescription() {
    return verboseDescription;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandDescription#description() description} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for description
   * @return A modified copy or the {@code this} object
   */
  public final CommandDescriptionImpl withDescription(@NonNull Description value) {
    if (this.description == value) return this;
    @NonNull Description newValue = Objects.requireNonNull(value, "description");
    return new CommandDescriptionImpl(this, newValue, this.verboseDescription);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandDescription#verboseDescription() verboseDescription} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for verboseDescription
   * @return A modified copy or the {@code this} object
   */
  public final CommandDescriptionImpl withVerboseDescription(@NonNull Description value) {
    if (this.verboseDescription == value) return this;
    @NonNull Description newValue = Objects.requireNonNull(value, "verboseDescription");
    return new CommandDescriptionImpl(this, this.description, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CommandDescriptionImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CommandDescriptionImpl
        && equalsByValue((CommandDescriptionImpl) another);
  }

  private boolean equalsByValue(CommandDescriptionImpl another) {
    return description.equals(another.description)
        && verboseDescription.equals(another.verboseDescription);
  }

  /**
   * Computes a hash code from attributes: {@code description}, {@code verboseDescription}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + description.hashCode();
    h += (h << 5) + verboseDescription.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandDescription} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandDescription{"
        + "description=" + description
        + ", verboseDescription=" + verboseDescription
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandDescription} instance.
   * @param description The value for the {@code description} attribute
   * @param verboseDescription The value for the {@code verboseDescription} attribute
   * @return An immutable CommandDescription instance
   */
  public static CommandDescriptionImpl of(@NonNull Description description, @NonNull Description verboseDescription) {
    return new CommandDescriptionImpl(description, verboseDescription);
  }

  /**
   * Creates an immutable copy of a {@link CommandDescription} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable CommandDescription instance
   */
  public static CommandDescriptionImpl copyOf(CommandDescription instance) {
    if (instance instanceof CommandDescriptionImpl) {
      return (CommandDescriptionImpl) instance;
    }
    return CommandDescriptionImpl.of(instance.description(), instance.verboseDescription());
  }
}
