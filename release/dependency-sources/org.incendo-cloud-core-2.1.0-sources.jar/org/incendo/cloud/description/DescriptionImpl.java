//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.description;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link Description}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code DescriptionImpl.of()}.
 */
@Generated(from = "Description", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class DescriptionImpl implements Description {
  private final @NonNull String textDescription;

  private DescriptionImpl(@NonNull String textDescription) {
    this.textDescription = Objects.requireNonNull(textDescription, "textDescription");
  }

  private DescriptionImpl(
      DescriptionImpl original,
      @NonNull String textDescription) {
    this.textDescription = textDescription;
  }

  /**
   * @return The value of the {@code textDescription} attribute
   */
  @Override
  public @NonNull String textDescription() {
    return textDescription;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link Description#textDescription() textDescription} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for textDescription
   * @return A modified copy or the {@code this} object
   */
  public final DescriptionImpl withTextDescription(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "textDescription");
    if (this.textDescription.equals(newValue)) return this;
    return new DescriptionImpl(this, newValue);
  }

  /**
   * This instance is equal to all instances of {@code DescriptionImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof DescriptionImpl
        && equalsByValue((DescriptionImpl) another);
  }

  private boolean equalsByValue(DescriptionImpl another) {
    return textDescription.equals(another.textDescription);
  }

  /**
   * Computes a hash code from attributes: {@code textDescription}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + textDescription.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code Description} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "Description{"
        + "textDescription=" + textDescription
        + "}";
  }

  /**
   * Construct a new immutable {@code Description} instance.
   * @param textDescription The value for the {@code textDescription} attribute
   * @return An immutable Description instance
   */
  public static DescriptionImpl of(@NonNull String textDescription) {
    return new DescriptionImpl(textDescription);
  }

  /**
   * Creates an immutable copy of a {@link Description} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable Description instance
   */
  public static DescriptionImpl copyOf(Description instance) {
    if (instance instanceof DescriptionImpl) {
      return (DescriptionImpl) instance;
    }
    return DescriptionImpl.of(instance.textDescription());
  }
}
