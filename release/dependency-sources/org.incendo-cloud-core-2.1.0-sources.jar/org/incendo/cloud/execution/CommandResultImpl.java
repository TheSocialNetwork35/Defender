//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.execution;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.context.CommandContext;

/**
 * Immutable implementation of {@link CommandResult}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CommandResultImpl.of()}.
 */
@Generated(from = "CommandResult", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CommandResultImpl<C> implements CommandResult<C> {
  private final @NonNull CommandContext<C> commandContext;

  private CommandResultImpl(
      @NonNull CommandContext<C> commandContext) {
    this.commandContext = Objects.requireNonNull(commandContext, "commandContext");
  }

  private CommandResultImpl(
      CommandResultImpl<C> original,
      @NonNull CommandContext<C> commandContext) {
    this.commandContext = commandContext;
  }

  /**
   * @return The value of the {@code commandContext} attribute
   */
  @Override
  public @NonNull CommandContext<C> commandContext() {
    return commandContext;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandResult#commandContext() commandContext} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandContext
   * @return A modified copy or the {@code this} object
   */
  public final CommandResultImpl<C> withCommandContext(@NonNull CommandContext<C> value) {
    if (this.commandContext == value) return this;
    @NonNull CommandContext<C> newValue = Objects.requireNonNull(value, "commandContext");
    return new CommandResultImpl<>(this, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CommandResultImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CommandResultImpl<?>
        && equalsByValue((CommandResultImpl<?>) another);
  }

  private boolean equalsByValue(CommandResultImpl<?> another) {
    return commandContext.equals(another.commandContext);
  }

  /**
   * Computes a hash code from attributes: {@code commandContext}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + commandContext.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandResult} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandResult{"
        + "commandContext=" + commandContext
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandResult} instance.
 * @param <C> generic parameter C
   * @param commandContext The value for the {@code commandContext} attribute
   * @return An immutable CommandResult instance
   */
  public static <C> CommandResultImpl<C> of(@NonNull CommandContext<C> commandContext) {
    return new CommandResultImpl<>(commandContext);
  }

  /**
   * Creates an immutable copy of a {@link CommandResult} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable CommandResult instance
   */
  public static <C> CommandResultImpl<C> copyOf(CommandResult<C> instance) {
    if (instance instanceof CommandResultImpl<?>) {
      return (CommandResultImpl<C>) instance;
    }
    return CommandResultImpl.<C>of(instance.commandContext());
  }
}
