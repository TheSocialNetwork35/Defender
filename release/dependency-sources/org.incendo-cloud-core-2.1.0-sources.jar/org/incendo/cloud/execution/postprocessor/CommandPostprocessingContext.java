//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.execution.postprocessor;

import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Value;
import org.incendo.cloud.Command;
import org.incendo.cloud.context.CommandContext;
import org.incendo.cloud.internal.ImmutableImpl;

/**
 * Context for {@link CommandPostprocessor command postprocessors}.
 *
 * @param <C> command sender type
 */
@Value.Immutable
@ImmutableImpl
@API(status = API.Status.STABLE)
public interface CommandPostprocessingContext<C> {

    /**
     * Returns a new postprocessing context.
     *
     * @param <C>            command sender type
     * @param commandContext command context
     * @param command        parsed command
     * @return the context instance
     */
    static <C> @NonNull CommandPostprocessingContext<C> of(
            final @NonNull CommandContext<C> commandContext,
            final @NonNull Command<C> command
    ) {
        return CommandPostprocessingContextImpl.of(commandContext, command);
    }

    /**
     * Returns the command context.
     *
     * @return command context
     */
    @NonNull CommandContext<@NonNull C> commandContext();

    /**
     * Returns the command instance.
     *
     * @return command instance
     */
    @NonNull Command<@NonNull C> command();
}
