//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.execution.postprocessor;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.Command;
import org.incendo.cloud.context.CommandContext;

/**
 * Immutable implementation of {@link CommandPostprocessingContext}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CommandPostprocessingContextImpl.of()}.
 */
@Generated(from = "CommandPostprocessingContext", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CommandPostprocessingContextImpl<C>
    implements CommandPostprocessingContext<C> {
  private final @NonNull CommandContext<C> commandContext;
  private final @NonNull Command<C> command;

  private CommandPostprocessingContextImpl(
      @NonNull CommandContext<C> commandContext,
      @NonNull Command<C> command) {
    this.commandContext = Objects.requireNonNull(commandContext, "commandContext");
    this.command = Objects.requireNonNull(command, "command");
  }

  private CommandPostprocessingContextImpl(
      CommandPostprocessingContextImpl<C> original,
      @NonNull CommandContext<C> commandContext,
      @NonNull Command<C> command) {
    this.commandContext = commandContext;
    this.command = command;
  }

  /**
   * @return The value of the {@code commandContext} attribute
   */
  @Override
  public @NonNull CommandContext<C> commandContext() {
    return commandContext;
  }

  /**
   * @return The value of the {@code command} attribute
   */
  @Override
  public @NonNull Command<C> command() {
    return command;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandPostprocessingContext#commandContext() commandContext} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandContext
   * @return A modified copy or the {@code this} object
   */
  public final CommandPostprocessingContextImpl<C> withCommandContext(@NonNull CommandContext<C> value) {
    if (this.commandContext == value) return this;
    @NonNull CommandContext<C> newValue = Objects.requireNonNull(value, "commandContext");
    return new CommandPostprocessingContextImpl<>(this, newValue, this.command);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandPostprocessingContext#command() command} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for command
   * @return A modified copy or the {@code this} object
   */
  public final CommandPostprocessingContextImpl<C> withCommand(@NonNull Command<C> value) {
    if (this.command == value) return this;
    @NonNull Command<C> newValue = Objects.requireNonNull(value, "command");
    return new CommandPostprocessingContextImpl<>(this, this.commandContext, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CommandPostprocessingContextImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CommandPostprocessingContextImpl<?>
        && equalsByValue((CommandPostprocessingContextImpl<?>) another);
  }

  private boolean equalsByValue(CommandPostprocessingContextImpl<?> another) {
    return commandContext.equals(another.commandContext)
        && command.equals(another.command);
  }

  /**
   * Computes a hash code from attributes: {@code commandContext}, {@code command}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + commandContext.hashCode();
    h += (h << 5) + command.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandPostprocessingContext} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandPostprocessingContext{"
        + "commandContext=" + commandContext
        + ", command=" + command
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandPostprocessingContext} instance.
 * @param <C> generic parameter C
   * @param commandContext The value for the {@code commandContext} attribute
   * @param command The value for the {@code command} attribute
   * @return An immutable CommandPostprocessingContext instance
   */
  public static <C> CommandPostprocessingContextImpl<C> of(@NonNull CommandContext<C> commandContext, @NonNull Command<C> command) {
    return new CommandPostprocessingContextImpl<>(commandContext, command);
  }

  /**
   * Creates an immutable copy of a {@link CommandPostprocessingContext} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable CommandPostprocessingContext instance
   */
  public static <C> CommandPostprocessingContextImpl<C> copyOf(CommandPostprocessingContext<C> instance) {
    if (instance instanceof CommandPostprocessingContextImpl<?>) {
      return (CommandPostprocessingContextImpl<C>) instance;
    }
    return CommandPostprocessingContextImpl.<C>of(instance.commandContext(), instance.command());
  }
}
