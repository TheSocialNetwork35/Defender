//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.execution.preprocessor;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.context.CommandContext;
import org.incendo.cloud.context.CommandInput;

/**
 * Immutable implementation of {@link CommandPreprocessingContext}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CommandPreprocessingContextImpl.of()}.
 */
@Generated(from = "CommandPreprocessingContext", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CommandPreprocessingContextImpl<C>
    implements CommandPreprocessingContext<C> {
  private final @NonNull CommandContext<C> commandContext;
  private final @NonNull CommandInput commandInput;

  private CommandPreprocessingContextImpl(
      @NonNull CommandContext<C> commandContext,
      @NonNull CommandInput commandInput) {
    this.commandContext = Objects.requireNonNull(commandContext, "commandContext");
    this.commandInput = Objects.requireNonNull(commandInput, "commandInput");
  }

  private CommandPreprocessingContextImpl(
      CommandPreprocessingContextImpl<C> original,
      @NonNull CommandContext<C> commandContext,
      @NonNull CommandInput commandInput) {
    this.commandContext = commandContext;
    this.commandInput = commandInput;
  }

  /**
   * @return The value of the {@code commandContext} attribute
   */
  @Override
  public @NonNull CommandContext<C> commandContext() {
    return commandContext;
  }

  /**
   * @return The value of the {@code commandInput} attribute
   */
  @Override
  public @NonNull CommandInput commandInput() {
    return commandInput;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandPreprocessingContext#commandContext() commandContext} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandContext
   * @return A modified copy or the {@code this} object
   */
  public final CommandPreprocessingContextImpl<C> withCommandContext(@NonNull CommandContext<C> value) {
    if (this.commandContext == value) return this;
    @NonNull CommandContext<C> newValue = Objects.requireNonNull(value, "commandContext");
    return new CommandPreprocessingContextImpl<>(this, newValue, this.commandInput);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandPreprocessingContext#commandInput() commandInput} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandInput
   * @return A modified copy or the {@code this} object
   */
  public final CommandPreprocessingContextImpl<C> withCommandInput(@NonNull CommandInput value) {
    if (this.commandInput == value) return this;
    @NonNull CommandInput newValue = Objects.requireNonNull(value, "commandInput");
    return new CommandPreprocessingContextImpl<>(this, this.commandContext, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CommandPreprocessingContextImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CommandPreprocessingContextImpl<?>
        && equalsByValue((CommandPreprocessingContextImpl<?>) another);
  }

  private boolean equalsByValue(CommandPreprocessingContextImpl<?> another) {
    return commandContext.equals(another.commandContext)
        && commandInput.equals(another.commandInput);
  }

  /**
   * Computes a hash code from attributes: {@code commandContext}, {@code commandInput}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + commandContext.hashCode();
    h += (h << 5) + commandInput.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandPreprocessingContext} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandPreprocessingContext{"
        + "commandContext=" + commandContext
        + ", commandInput=" + commandInput
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandPreprocessingContext} instance.
 * @param <C> generic parameter C
   * @param commandContext The value for the {@code commandContext} attribute
   * @param commandInput The value for the {@code commandInput} attribute
   * @return An immutable CommandPreprocessingContext instance
   */
  public static <C> CommandPreprocessingContextImpl<C> of(@NonNull CommandContext<C> commandContext, @NonNull CommandInput commandInput) {
    return new CommandPreprocessingContextImpl<>(commandContext, commandInput);
  }

  /**
   * Creates an immutable copy of a {@link CommandPreprocessingContext} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable CommandPreprocessingContext instance
   */
  public static <C> CommandPreprocessingContextImpl<C> copyOf(CommandPreprocessingContext<C> instance) {
    if (instance instanceof CommandPreprocessingContextImpl<?>) {
      return (CommandPreprocessingContextImpl<C>) instance;
    }
    return CommandPreprocessingContextImpl.<C>of(instance.commandContext(), instance.commandInput());
  }
}
