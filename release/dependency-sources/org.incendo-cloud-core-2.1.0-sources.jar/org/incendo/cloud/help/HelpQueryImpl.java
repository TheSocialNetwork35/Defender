//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.help;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link HelpQuery}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code HelpQueryImpl.of()}.
 */
@Generated(from = "HelpQuery", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class HelpQueryImpl<C> implements HelpQuery<C> {
  private final C sender;
  private final @NonNull String query;

  private HelpQueryImpl(C sender, @NonNull String query) {
    this.sender = Objects.requireNonNull(sender, "sender");
    this.query = Objects.requireNonNull(query, "query");
  }

  private HelpQueryImpl(
      HelpQueryImpl<C> original,
      C sender,
      @NonNull String query) {
    this.sender = sender;
    this.query = query;
  }

  /**
   * @return The value of the {@code sender} attribute
   */
  @Override
  public C sender() {
    return sender;
  }

  /**
   * @return The value of the {@code query} attribute
   */
  @Override
  public @NonNull String query() {
    return query;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link HelpQuery#sender() sender} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for sender
   * @return A modified copy or the {@code this} object
   */
  public final HelpQueryImpl<C> withSender(C value) {
    if (this.sender == value) return this;
    C newValue = Objects.requireNonNull(value, "sender");
    return new HelpQueryImpl<>(this, newValue, this.query);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link HelpQuery#query() query} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for query
   * @return A modified copy or the {@code this} object
   */
  public final HelpQueryImpl<C> withQuery(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "query");
    if (this.query.equals(newValue)) return this;
    return new HelpQueryImpl<>(this, this.sender, newValue);
  }

  /**
   * This instance is equal to all instances of {@code HelpQueryImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof HelpQueryImpl<?>
        && equalsByValue((HelpQueryImpl<?>) another);
  }

  private boolean equalsByValue(HelpQueryImpl<?> another) {
    return sender.equals(another.sender)
        && query.equals(another.query);
  }

  /**
   * Computes a hash code from attributes: {@code sender}, {@code query}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + sender.hashCode();
    h += (h << 5) + query.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code HelpQuery} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "HelpQuery{"
        + "sender=" + sender
        + ", query=" + query
        + "}";
  }

  /**
   * Construct a new immutable {@code HelpQuery} instance.
 * @param <C> generic parameter C
   * @param sender The value for the {@code sender} attribute
   * @param query The value for the {@code query} attribute
   * @return An immutable HelpQuery instance
   */
  public static <C> HelpQueryImpl<C> of(C sender, @NonNull String query) {
    return new HelpQueryImpl<>(sender, query);
  }

  /**
   * Creates an immutable copy of a {@link HelpQuery} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable HelpQuery instance
   */
  public static <C> HelpQueryImpl<C> copyOf(HelpQuery<C> instance) {
    if (instance instanceof HelpQueryImpl<?>) {
      return (HelpQueryImpl<C>) instance;
    }
    return HelpQueryImpl.<C>of(instance.sender(), instance.query());
  }
}
