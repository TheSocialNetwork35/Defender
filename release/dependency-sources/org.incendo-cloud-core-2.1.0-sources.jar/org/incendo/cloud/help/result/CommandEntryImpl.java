//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.help.result;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.Command;

/**
 * Immutable implementation of {@link CommandEntry}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CommandEntryImpl.of()}.
 */
@Generated(from = "CommandEntry", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CommandEntryImpl<C> implements CommandEntry<C> {
  private final @NonNull Command<C> command;
  private final @NonNull String syntax;

  private CommandEntryImpl(
      @NonNull Command<C> command,
      @NonNull String syntax) {
    this.command = Objects.requireNonNull(command, "command");
    this.syntax = Objects.requireNonNull(syntax, "syntax");
  }

  private CommandEntryImpl(
      CommandEntryImpl<C> original,
      @NonNull Command<C> command,
      @NonNull String syntax) {
    this.command = command;
    this.syntax = syntax;
  }

  /**
   * @return The value of the {@code command} attribute
   */
  @Override
  public @NonNull Command<C> command() {
    return command;
  }

  /**
   * @return The value of the {@code syntax} attribute
   */
  @Override
  public @NonNull String syntax() {
    return syntax;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandEntry#command() command} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for command
   * @return A modified copy or the {@code this} object
   */
  public final CommandEntryImpl<C> withCommand(@NonNull Command<C> value) {
    if (this.command == value) return this;
    @NonNull Command<C> newValue = Objects.requireNonNull(value, "command");
    return new CommandEntryImpl<>(this, newValue, this.syntax);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CommandEntry#syntax() syntax} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for syntax
   * @return A modified copy or the {@code this} object
   */
  public final CommandEntryImpl<C> withSyntax(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "syntax");
    if (this.syntax.equals(newValue)) return this;
    return new CommandEntryImpl<>(this, this.command, newValue);
  }

  /**
   * This instance is equal to all instances of {@code CommandEntryImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof CommandEntryImpl<?>
        && equalsByValue((CommandEntryImpl<?>) another);
  }

  private boolean equalsByValue(CommandEntryImpl<?> another) {
    return command.equals(another.command)
        && syntax.equals(another.syntax);
  }

  /**
   * Computes a hash code from attributes: {@code command}, {@code syntax}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + command.hashCode();
    h += (h << 5) + syntax.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code CommandEntry} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CommandEntry{"
        + "command=" + command
        + ", syntax=" + syntax
        + "}";
  }

  /**
   * Construct a new immutable {@code CommandEntry} instance.
 * @param <C> generic parameter C
   * @param command The value for the {@code command} attribute
   * @param syntax The value for the {@code syntax} attribute
   * @return An immutable CommandEntry instance
   */
  public static <C> CommandEntryImpl<C> of(@NonNull Command<C> command, @NonNull String syntax) {
    return new CommandEntryImpl<>(command, syntax);
  }

  /**
   * Creates an immutable copy of a {@link CommandEntry} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable CommandEntry instance
   */
  public static <C> CommandEntryImpl<C> copyOf(CommandEntry<C> instance) {
    if (instance instanceof CommandEntryImpl<?>) {
      return (CommandEntryImpl<C>) instance;
    }
    return CommandEntryImpl.<C>of(instance.command(), instance.syntax());
  }
}
