//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.help.result;

import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.help.HelpQuery;

/**
 * Immutable implementation of {@link IndexCommandResult}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code IndexCommandResultImpl.of()}.
 */
@Generated(from = "IndexCommandResult", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class IndexCommandResultImpl<C> implements IndexCommandResult<C> {
  private final @NonNull HelpQuery<C> query;
  private final @NonNull List<CommandEntry<C>> entries;

  private IndexCommandResultImpl(
      @NonNull HelpQuery<C> query,
      Iterable<? extends CommandEntry<C>> entries) {
    this.query = Objects.requireNonNull(query, "query");
    this.entries = createUnmodifiableList(false, createSafeList(entries, true, false));
  }

  private IndexCommandResultImpl(
      IndexCommandResultImpl<C> original,
      @NonNull HelpQuery<C> query,
      @NonNull List<CommandEntry<C>> entries) {
    this.query = query;
    this.entries = entries;
  }

  /**
   * @return The value of the {@code query} attribute
   */
  @Override
  public @NonNull HelpQuery<C> query() {
    return query;
  }

  /**
   * @return The value of the {@code entries} attribute
   */
  @Override
  public @NonNull List<CommandEntry<C>> entries() {
    return entries;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link IndexCommandResult#query() query} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for query
   * @return A modified copy or the {@code this} object
   */
  public final IndexCommandResultImpl<C> withQuery(@NonNull HelpQuery<C> value) {
    if (this.query == value) return this;
    @NonNull HelpQuery<C> newValue = Objects.requireNonNull(value, "query");
    return new IndexCommandResultImpl<>(this, newValue, this.entries);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link IndexCommandResult#entries() entries}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  @SafeVarargs @SuppressWarnings("varargs")
  public final IndexCommandResultImpl<C> withEntries(CommandEntry<C>... elements) {
    @NonNull List<CommandEntry<C>> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new IndexCommandResultImpl<>(this, this.query, newValue);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link IndexCommandResult#entries() entries}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of entries elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final IndexCommandResultImpl<C> withEntries(Iterable<? extends CommandEntry<C>> elements) {
    if (this.entries == elements) return this;
    @NonNull List<CommandEntry<C>> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new IndexCommandResultImpl<>(this, this.query, newValue);
  }

  /**
   * This instance is equal to all instances of {@code IndexCommandResultImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof IndexCommandResultImpl<?>
        && equalsByValue((IndexCommandResultImpl<?>) another);
  }

  private boolean equalsByValue(IndexCommandResultImpl<?> another) {
    return query.equals(another.query)
        && entries.equals(another.entries);
  }

  /**
   * Computes a hash code from attributes: {@code query}, {@code entries}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + query.hashCode();
    h += (h << 5) + entries.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code IndexCommandResult} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "IndexCommandResult{"
        + "query=" + query
        + ", entries=" + entries
        + "}";
  }

  /**
   * Construct a new immutable {@code IndexCommandResult} instance.
 * @param <C> generic parameter C
   * @param query The value for the {@code query} attribute
   * @param entries The value for the {@code entries} attribute
   * @return An immutable IndexCommandResult instance
   */
  public static <C> IndexCommandResultImpl<C> of(@NonNull HelpQuery<C> query, @NonNull List<CommandEntry<C>> entries) {
    return of(query, (Iterable<? extends CommandEntry<C>>) entries);
  }

  /**
   * Construct a new immutable {@code IndexCommandResult} instance.
 * @param <C> generic parameter C
   * @param query The value for the {@code query} attribute
   * @param entries The value for the {@code entries} attribute
   * @return An immutable IndexCommandResult instance
   */
  public static <C> IndexCommandResultImpl<C> of(@NonNull HelpQuery<C> query, Iterable<? extends CommandEntry<C>> entries) {
    return new IndexCommandResultImpl<>(query, entries);
  }

  /**
   * Creates an immutable copy of a {@link IndexCommandResult} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable IndexCommandResult instance
   */
  public static <C> IndexCommandResultImpl<C> copyOf(IndexCommandResult<C> instance) {
    if (instance instanceof IndexCommandResultImpl<?>) {
      return (IndexCommandResultImpl<C>) instance;
    }
    return IndexCommandResultImpl.<C>of(instance.query(), instance.entries());
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>(size);
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<? extends T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
