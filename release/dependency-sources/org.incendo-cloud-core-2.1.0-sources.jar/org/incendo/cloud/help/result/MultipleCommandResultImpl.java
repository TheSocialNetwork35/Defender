//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.help.result;

import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.help.HelpQuery;

/**
 * Immutable implementation of {@link MultipleCommandResult}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code MultipleCommandResultImpl.of()}.
 */
@Generated(from = "MultipleCommandResult", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class MultipleCommandResultImpl<C>
    implements MultipleCommandResult<C> {
  private final @NonNull HelpQuery<C> query;
  private final @NonNull String longestPath;
  private final @NonNull List<String> childSuggestions;

  private MultipleCommandResultImpl(
      @NonNull HelpQuery<C> query,
      @NonNull String longestPath,
      Iterable<String> childSuggestions) {
    this.query = Objects.requireNonNull(query, "query");
    this.longestPath = Objects.requireNonNull(longestPath, "longestPath");
    this.childSuggestions = createUnmodifiableList(false, createSafeList(childSuggestions, true, false));
  }

  private MultipleCommandResultImpl(
      MultipleCommandResultImpl<C> original,
      @NonNull HelpQuery<C> query,
      @NonNull String longestPath,
      @NonNull List<String> childSuggestions) {
    this.query = query;
    this.longestPath = longestPath;
    this.childSuggestions = childSuggestions;
  }

  /**
   * @return The value of the {@code query} attribute
   */
  @Override
  public @NonNull HelpQuery<C> query() {
    return query;
  }

  /**
   * @return The value of the {@code longestPath} attribute
   */
  @Override
  public @NonNull String longestPath() {
    return longestPath;
  }

  /**
   * @return The value of the {@code childSuggestions} attribute
   */
  @Override
  public @NonNull List<String> childSuggestions() {
    return childSuggestions;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link MultipleCommandResult#query() query} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for query
   * @return A modified copy or the {@code this} object
   */
  public final MultipleCommandResultImpl<C> withQuery(@NonNull HelpQuery<C> value) {
    if (this.query == value) return this;
    @NonNull HelpQuery<C> newValue = Objects.requireNonNull(value, "query");
    return new MultipleCommandResultImpl<>(this, newValue, this.longestPath, this.childSuggestions);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link MultipleCommandResult#longestPath() longestPath} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for longestPath
   * @return A modified copy or the {@code this} object
   */
  public final MultipleCommandResultImpl<C> withLongestPath(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "longestPath");
    if (this.longestPath.equals(newValue)) return this;
    return new MultipleCommandResultImpl<>(this, this.query, newValue, this.childSuggestions);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link MultipleCommandResult#childSuggestions() childSuggestions}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final MultipleCommandResultImpl<C> withChildSuggestions(String... elements) {
    @NonNull List<String> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new MultipleCommandResultImpl<>(this, this.query, this.longestPath, newValue);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link MultipleCommandResult#childSuggestions() childSuggestions}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of childSuggestions elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final MultipleCommandResultImpl<C> withChildSuggestions(Iterable<String> elements) {
    if (this.childSuggestions == elements) return this;
    @NonNull List<String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new MultipleCommandResultImpl<>(this, this.query, this.longestPath, newValue);
  }

  /**
   * This instance is equal to all instances of {@code MultipleCommandResultImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof MultipleCommandResultImpl<?>
        && equalsByValue((MultipleCommandResultImpl<?>) another);
  }

  private boolean equalsByValue(MultipleCommandResultImpl<?> another) {
    return query.equals(another.query)
        && longestPath.equals(another.longestPath)
        && childSuggestions.equals(another.childSuggestions);
  }

  /**
   * Computes a hash code from attributes: {@code query}, {@code longestPath}, {@code childSuggestions}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + query.hashCode();
    h += (h << 5) + longestPath.hashCode();
    h += (h << 5) + childSuggestions.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code MultipleCommandResult} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "MultipleCommandResult{"
        + "query=" + query
        + ", longestPath=" + longestPath
        + ", childSuggestions=" + childSuggestions
        + "}";
  }

  /**
   * Construct a new immutable {@code MultipleCommandResult} instance.
 * @param <C> generic parameter C
   * @param query The value for the {@code query} attribute
   * @param longestPath The value for the {@code longestPath} attribute
   * @param childSuggestions The value for the {@code childSuggestions} attribute
   * @return An immutable MultipleCommandResult instance
   */
  public static <C> MultipleCommandResultImpl<C> of(@NonNull HelpQuery<C> query, @NonNull String longestPath, @NonNull List<String> childSuggestions) {
    return of(query, longestPath, (Iterable<String>) childSuggestions);
  }

  /**
   * Construct a new immutable {@code MultipleCommandResult} instance.
 * @param <C> generic parameter C
   * @param query The value for the {@code query} attribute
   * @param longestPath The value for the {@code longestPath} attribute
   * @param childSuggestions The value for the {@code childSuggestions} attribute
   * @return An immutable MultipleCommandResult instance
   */
  public static <C> MultipleCommandResultImpl<C> of(@NonNull HelpQuery<C> query, @NonNull String longestPath, Iterable<String> childSuggestions) {
    return new MultipleCommandResultImpl<>(query, longestPath, childSuggestions);
  }

  /**
   * Creates an immutable copy of a {@link MultipleCommandResult} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable MultipleCommandResult instance
   */
  public static <C> MultipleCommandResultImpl<C> copyOf(MultipleCommandResult<C> instance) {
    if (instance instanceof MultipleCommandResultImpl<?>) {
      return (MultipleCommandResultImpl<C>) instance;
    }
    return MultipleCommandResultImpl.<C>of(instance.query(), instance.longestPath(), instance.childSuggestions());
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>(size);
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<? extends T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
