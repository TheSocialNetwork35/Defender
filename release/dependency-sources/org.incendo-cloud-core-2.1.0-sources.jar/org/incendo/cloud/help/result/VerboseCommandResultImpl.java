//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.help.result;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.help.HelpQuery;

/**
 * Immutable implementation of {@link VerboseCommandResult}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code VerboseCommandResultImpl.of()}.
 */
@Generated(from = "VerboseCommandResult", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class VerboseCommandResultImpl<C>
    implements VerboseCommandResult<C> {
  private final @NonNull HelpQuery<C> query;
  private final @NonNull CommandEntry<C> entry;

  private VerboseCommandResultImpl(
      @NonNull HelpQuery<C> query,
      @NonNull CommandEntry<C> entry) {
    this.query = Objects.requireNonNull(query, "query");
    this.entry = Objects.requireNonNull(entry, "entry");
  }

  private VerboseCommandResultImpl(
      VerboseCommandResultImpl<C> original,
      @NonNull HelpQuery<C> query,
      @NonNull CommandEntry<C> entry) {
    this.query = query;
    this.entry = entry;
  }

  /**
   * @return The value of the {@code query} attribute
   */
  @Override
  public @NonNull HelpQuery<C> query() {
    return query;
  }

  /**
   * @return The value of the {@code entry} attribute
   */
  @Override
  public @NonNull CommandEntry<C> entry() {
    return entry;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link VerboseCommandResult#query() query} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for query
   * @return A modified copy or the {@code this} object
   */
  public final VerboseCommandResultImpl<C> withQuery(@NonNull HelpQuery<C> value) {
    if (this.query == value) return this;
    @NonNull HelpQuery<C> newValue = Objects.requireNonNull(value, "query");
    return new VerboseCommandResultImpl<>(this, newValue, this.entry);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link VerboseCommandResult#entry() entry} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for entry
   * @return A modified copy or the {@code this} object
   */
  public final VerboseCommandResultImpl<C> withEntry(@NonNull CommandEntry<C> value) {
    if (this.entry == value) return this;
    @NonNull CommandEntry<C> newValue = Objects.requireNonNull(value, "entry");
    return new VerboseCommandResultImpl<>(this, this.query, newValue);
  }

  /**
   * This instance is equal to all instances of {@code VerboseCommandResultImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof VerboseCommandResultImpl<?>
        && equalsByValue((VerboseCommandResultImpl<?>) another);
  }

  private boolean equalsByValue(VerboseCommandResultImpl<?> another) {
    return query.equals(another.query)
        && entry.equals(another.entry);
  }

  /**
   * Computes a hash code from attributes: {@code query}, {@code entry}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + query.hashCode();
    h += (h << 5) + entry.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code VerboseCommandResult} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "VerboseCommandResult{"
        + "query=" + query
        + ", entry=" + entry
        + "}";
  }

  /**
   * Construct a new immutable {@code VerboseCommandResult} instance.
 * @param <C> generic parameter C
   * @param query The value for the {@code query} attribute
   * @param entry The value for the {@code entry} attribute
   * @return An immutable VerboseCommandResult instance
   */
  public static <C> VerboseCommandResultImpl<C> of(@NonNull HelpQuery<C> query, @NonNull CommandEntry<C> entry) {
    return new VerboseCommandResultImpl<>(query, entry);
  }

  /**
   * Creates an immutable copy of a {@link VerboseCommandResult} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable VerboseCommandResult instance
   */
  public static <C> VerboseCommandResultImpl<C> copyOf(VerboseCommandResult<C> instance) {
    if (instance instanceof VerboseCommandResultImpl<?>) {
      return (VerboseCommandResultImpl<C>) instance;
    }
    return VerboseCommandResultImpl.<C>of(instance.query(), instance.entry());
  }
}
