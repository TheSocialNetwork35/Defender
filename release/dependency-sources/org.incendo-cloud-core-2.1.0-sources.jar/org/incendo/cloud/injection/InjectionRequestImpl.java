//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.injection;

import com.google.errorprone.annotations.Var;
import io.leangen.geantyref.TypeToken;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.context.CommandContext;
import org.incendo.cloud.util.annotation.AnnotationAccessor;

/**
 * Immutable implementation of {@link InjectionRequest}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code InjectionRequestImpl.of()}.
 */
@Generated(from = "InjectionRequest", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class InjectionRequestImpl<C> implements InjectionRequest<C> {
  private final @NonNull CommandContext<C> commandContext;
  private final @NonNull TypeToken<?> injectedType;
  private transient final @NonNull Class<?> injectedClass;
  private final @NonNull AnnotationAccessor annotationAccessor;

  private InjectionRequestImpl(
      @NonNull CommandContext<C> commandContext,
      @NonNull TypeToken<?> injectedType,
      @NonNull AnnotationAccessor annotationAccessor) {
    this.commandContext = Objects.requireNonNull(commandContext, "commandContext");
    this.injectedType = Objects.requireNonNull(injectedType, "injectedType");
    this.annotationAccessor = Objects.requireNonNull(annotationAccessor, "annotationAccessor");
    this.injectedClass = Objects.requireNonNull(InjectionRequest.super.injectedClass(), "injectedClass");
  }

  private InjectionRequestImpl(
      InjectionRequestImpl<C> original,
      @NonNull CommandContext<C> commandContext,
      @NonNull TypeToken<?> injectedType,
      @NonNull AnnotationAccessor annotationAccessor) {
    this.commandContext = commandContext;
    this.injectedType = injectedType;
    this.annotationAccessor = annotationAccessor;
    this.injectedClass = Objects.requireNonNull(InjectionRequest.super.injectedClass(), "injectedClass");
  }

  /**
   * @return The value of the {@code commandContext} attribute
   */
  @Override
  public @NonNull CommandContext<C> commandContext() {
    return commandContext;
  }

  /**
   * @return The value of the {@code injectedType} attribute
   */
  @Override
  public @NonNull TypeToken<?> injectedType() {
    return injectedType;
  }

  /**
   * @return The computed-at-construction value of the {@code injectedClass} attribute
   */
  @Override
  public @NonNull Class<?> injectedClass() {
    return injectedClass;
  }

  /**
   * @return The value of the {@code annotationAccessor} attribute
   */
  @Override
  public @NonNull AnnotationAccessor annotationAccessor() {
    return annotationAccessor;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link InjectionRequest#commandContext() commandContext} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandContext
   * @return A modified copy or the {@code this} object
   */
  public final InjectionRequestImpl<C> withCommandContext(@NonNull CommandContext<C> value) {
    if (this.commandContext == value) return this;
    @NonNull CommandContext<C> newValue = Objects.requireNonNull(value, "commandContext");
    return new InjectionRequestImpl<>(this, newValue, this.injectedType, this.annotationAccessor);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link InjectionRequest#injectedType() injectedType} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for injectedType
   * @return A modified copy or the {@code this} object
   */
  public final InjectionRequestImpl<C> withInjectedType(@NonNull TypeToken<?> value) {
    if (this.injectedType == value) return this;
    @NonNull TypeToken<?> newValue = Objects.requireNonNull(value, "injectedType");
    return new InjectionRequestImpl<>(this, this.commandContext, newValue, this.annotationAccessor);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link InjectionRequest#annotationAccessor() annotationAccessor} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for annotationAccessor
   * @return A modified copy or the {@code this} object
   */
  public final InjectionRequestImpl<C> withAnnotationAccessor(@NonNull AnnotationAccessor value) {
    if (this.annotationAccessor == value) return this;
    @NonNull AnnotationAccessor newValue = Objects.requireNonNull(value, "annotationAccessor");
    return new InjectionRequestImpl<>(this, this.commandContext, this.injectedType, newValue);
  }

  /**
   * This instance is equal to all instances of {@code InjectionRequestImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof InjectionRequestImpl<?>
        && equalsByValue((InjectionRequestImpl<?>) another);
  }

  private boolean equalsByValue(InjectionRequestImpl<?> another) {
    return commandContext.equals(another.commandContext)
        && injectedType.equals(another.injectedType)
        && injectedClass.equals(another.injectedClass)
        && annotationAccessor.equals(another.annotationAccessor);
  }

  /**
   * Computes a hash code from attributes: {@code commandContext}, {@code injectedType}, {@code injectedClass}, {@code annotationAccessor}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + commandContext.hashCode();
    h += (h << 5) + injectedType.hashCode();
    h += (h << 5) + injectedClass.hashCode();
    h += (h << 5) + annotationAccessor.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code InjectionRequest} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "InjectionRequest{"
        + "commandContext=" + commandContext
        + ", injectedType=" + injectedType
        + ", injectedClass=" + injectedClass
        + ", annotationAccessor=" + annotationAccessor
        + "}";
  }

  /**
   * Construct a new immutable {@code InjectionRequest} instance.
 * @param <C> generic parameter C
   * @param commandContext The value for the {@code commandContext} attribute
   * @param injectedType The value for the {@code injectedType} attribute
   * @param annotationAccessor The value for the {@code annotationAccessor} attribute
   * @return An immutable InjectionRequest instance
   */
  public static <C> InjectionRequestImpl<C> of(@NonNull CommandContext<C> commandContext, @NonNull TypeToken<?> injectedType, @NonNull AnnotationAccessor annotationAccessor) {
    return new InjectionRequestImpl<>(commandContext, injectedType, annotationAccessor);
  }

  /**
   * Creates an immutable copy of a {@link InjectionRequest} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param instance The instance to copy
   * @return A copied immutable InjectionRequest instance
   */
  public static <C> InjectionRequestImpl<C> copyOf(InjectionRequest<C> instance) {
    if (instance instanceof InjectionRequestImpl<?>) {
      return (InjectionRequestImpl<C>) instance;
    }
    return InjectionRequestImpl.<C>of(instance.commandContext(), instance.injectedType(), instance.annotationAccessor());
  }
}
