//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.key;

import io.leangen.geantyref.TypeToken;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link CloudKey}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code CloudKeyImpl.of()}.
 */
@Generated(from = "CloudKey", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class CloudKeyImpl<T> extends CloudKey<T> {
  private final @NonNull String name;
  private final @NonNull TypeToken<T> type;

  private CloudKeyImpl(
      @NonNull String name,
      @NonNull TypeToken<T> type) {
    this.name = Objects.requireNonNull(name, "name");
    this.type = Objects.requireNonNull(type, "type");
  }

  private CloudKeyImpl(
      CloudKeyImpl<T> original,
      @NonNull String name,
      @NonNull TypeToken<T> type) {
    this.name = name;
    this.type = type;
  }

  /**
   * @return The value of the {@code name} attribute
   */
  @Override
  public @NonNull String name() {
    return name;
  }

  /**
   * @return The value of the {@code type} attribute
   */
  @Override
  public @NonNull TypeToken<T> type() {
    return type;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CloudKey#name() name} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for name
   * @return A modified copy or the {@code this} object
   */
  public final CloudKeyImpl<T> withName(@NonNull String value) {
    @NonNull String newValue = Objects.requireNonNull(value, "name");
    if (this.name.equals(newValue)) return this;
    return new CloudKeyImpl<>(this, newValue, this.type);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link CloudKey#type() type} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for type
   * @return A modified copy or the {@code this} object
   */
  public final CloudKeyImpl<T> withType(@NonNull TypeToken<T> value) {
    if (this.type == value) return this;
    @NonNull TypeToken<T> newValue = Objects.requireNonNull(value, "type");
    return new CloudKeyImpl<>(this, this.name, newValue);
  }

  /**
   * Prints the immutable value {@code CloudKey} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "CloudKey{"
        + "name=" + name
        + ", type=" + type
        + "}";
  }

  /**
   * Construct a new immutable {@code CloudKey} instance.
 * @param <T> generic parameter T
   * @param name The value for the {@code name} attribute
   * @param type The value for the {@code type} attribute
   * @return An immutable CloudKey instance
   */
  public static <T> CloudKeyImpl<T> of(@NonNull String name, @NonNull TypeToken<T> type) {
    return new CloudKeyImpl<>(name, type);
  }

  /**
   * Creates an immutable copy of a {@link CloudKey} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <T> generic parameter T
   * @param instance The instance to copy
   * @return A copied immutable CloudKey instance
   */
  public static <T> CloudKeyImpl<T> copyOf(CloudKey<T> instance) {
    if (instance instanceof CloudKeyImpl<?>) {
      return (CloudKeyImpl<T>) instance;
    }
    return CloudKeyImpl.<T>of(instance.name(), instance.type());
  }
}
