//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.parser;

import com.google.errorprone.annotations.Var;
import io.leangen.geantyref.TypeToken;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ParserDescriptor}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code ParserDescriptorImpl.of()}.
 */
@Generated(from = "ParserDescriptor", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class ParserDescriptorImpl<C, T> implements ParserDescriptor<C, T> {
  private final @NonNull ArgumentParser<C, T> parser;
  private final @NonNull TypeToken<T> valueType;

  private ParserDescriptorImpl(
      @NonNull ArgumentParser<C, T> parser,
      @NonNull TypeToken<T> valueType) {
    this.parser = Objects.requireNonNull(parser, "parser");
    this.valueType = Objects.requireNonNull(valueType, "valueType");
  }

  private ParserDescriptorImpl(
      ParserDescriptorImpl<C, T> original,
      @NonNull ArgumentParser<C, T> parser,
      @NonNull TypeToken<T> valueType) {
    this.parser = parser;
    this.valueType = valueType;
  }

  /**
   * @return The value of the {@code parser} attribute
   */
  @Override
  public @NonNull ArgumentParser<C, T> parser() {
    return parser;
  }

  /**
   * @return The value of the {@code valueType} attribute
   */
  @Override
  public @NonNull TypeToken<T> valueType() {
    return valueType;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ParserDescriptor#parser() parser} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for parser
   * @return A modified copy or the {@code this} object
   */
  public final ParserDescriptorImpl<C, T> withParser(@NonNull ArgumentParser<C, T> value) {
    if (this.parser == value) return this;
    @NonNull ArgumentParser<C, T> newValue = Objects.requireNonNull(value, "parser");
    return new ParserDescriptorImpl<>(this, newValue, this.valueType);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ParserDescriptor#valueType() valueType} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for valueType
   * @return A modified copy or the {@code this} object
   */
  public final ParserDescriptorImpl<C, T> withValueType(@NonNull TypeToken<T> value) {
    if (this.valueType == value) return this;
    @NonNull TypeToken<T> newValue = Objects.requireNonNull(value, "valueType");
    return new ParserDescriptorImpl<>(this, this.parser, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ParserDescriptorImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ParserDescriptorImpl<?, ?>
        && equalsByValue((ParserDescriptorImpl<?, ?>) another);
  }

  private boolean equalsByValue(ParserDescriptorImpl<?, ?> another) {
    return parser.equals(another.parser)
        && valueType.equals(another.valueType);
  }

  /**
   * Computes a hash code from attributes: {@code parser}, {@code valueType}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + parser.hashCode();
    h += (h << 5) + valueType.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ParserDescriptor} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ParserDescriptor{"
        + "parser=" + parser
        + ", valueType=" + valueType
        + "}";
  }

  /**
   * Construct a new immutable {@code ParserDescriptor} instance.
 * @param <C> generic parameter C
 * @param <T> generic parameter T
   * @param parser The value for the {@code parser} attribute
   * @param valueType The value for the {@code valueType} attribute
   * @return An immutable ParserDescriptor instance
   */
  public static <C, T> ParserDescriptorImpl<C, T> of(@NonNull ArgumentParser<C, T> parser, @NonNull TypeToken<T> valueType) {
    return new ParserDescriptorImpl<>(parser, valueType);
  }

  /**
   * Creates an immutable copy of a {@link ParserDescriptor} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param <T> generic parameter T
   * @param instance The instance to copy
   * @return A copied immutable ParserDescriptor instance
   */
  public static <C, T> ParserDescriptorImpl<C, T> copyOf(ParserDescriptor<C, T> instance) {
    if (instance instanceof ParserDescriptorImpl<?, ?>) {
      return (ParserDescriptorImpl<C, T>) instance;
    }
    return ParserDescriptorImpl.<C, T>of(instance.parser(), instance.valueType());
  }
}
