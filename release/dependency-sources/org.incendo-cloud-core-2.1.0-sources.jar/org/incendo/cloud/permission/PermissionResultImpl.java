//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.permission;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link PermissionResult}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code PermissionResultImpl.of()}.
 */
@Generated(from = "PermissionResult", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class PermissionResultImpl implements PermissionResult {
  private final boolean allowed;
  private final @NonNull Permission permission;

  private PermissionResultImpl(
      boolean allowed,
      @NonNull Permission permission) {
    this.allowed = allowed;
    this.permission = Objects.requireNonNull(permission, "permission");
  }

  private PermissionResultImpl(
      PermissionResultImpl original,
      boolean allowed,
      @NonNull Permission permission) {
    this.allowed = allowed;
    this.permission = permission;
  }

  /**
   * @return The value of the {@code allowed} attribute
   */
  @Override
  public boolean allowed() {
    return allowed;
  }

  /**
   * @return The value of the {@code permission} attribute
   */
  @Override
  public @NonNull Permission permission() {
    return permission;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PermissionResult#allowed() allowed} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for allowed
   * @return A modified copy or the {@code this} object
   */
  public final PermissionResultImpl withAllowed(boolean value) {
    if (this.allowed == value) return this;
    return new PermissionResultImpl(this, value, this.permission);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PermissionResult#permission() permission} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for permission
   * @return A modified copy or the {@code this} object
   */
  public final PermissionResultImpl withPermission(@NonNull Permission value) {
    if (this.permission == value) return this;
    @NonNull Permission newValue = Objects.requireNonNull(value, "permission");
    return new PermissionResultImpl(this, this.allowed, newValue);
  }

  /**
   * This instance is equal to all instances of {@code PermissionResultImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof PermissionResultImpl
        && equalsByValue((PermissionResultImpl) another);
  }

  private boolean equalsByValue(PermissionResultImpl another) {
    return allowed == another.allowed
        && permission.equals(another.permission);
  }

  /**
   * Computes a hash code from attributes: {@code allowed}, {@code permission}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Boolean.hashCode(allowed);
    h += (h << 5) + permission.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code PermissionResult} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "PermissionResult{"
        + "allowed=" + allowed
        + ", permission=" + permission
        + "}";
  }

  /**
   * Construct a new immutable {@code PermissionResult} instance.
   * @param allowed The value for the {@code allowed} attribute
   * @param permission The value for the {@code permission} attribute
   * @return An immutable PermissionResult instance
   */
  public static PermissionResultImpl of(boolean allowed, @NonNull Permission permission) {
    return new PermissionResultImpl(allowed, permission);
  }

  /**
   * Creates an immutable copy of a {@link PermissionResult} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable PermissionResult instance
   */
  public static PermissionResultImpl copyOf(PermissionResult instance) {
    if (instance instanceof PermissionResultImpl) {
      return (PermissionResultImpl) instance;
    }
    return PermissionResultImpl.of(instance.allowed(), instance.permission());
  }
}
