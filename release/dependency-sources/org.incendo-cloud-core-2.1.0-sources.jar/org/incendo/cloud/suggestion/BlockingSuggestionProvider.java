//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.suggestion;

import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.incendo.cloud.context.CommandContext;
import org.incendo.cloud.context.CommandInput;

/**
 * Specialized variant of {@link SuggestionProvider} that does work on the calling thread.
 *
 * <p>In the case that a specific thread context isn't required, this is usually simpler
 * to implement than {@link SuggestionProvider}.</p>
 *
 * @param <C> command sender type
 */
@FunctionalInterface
@API(status = API.Status.STABLE)
public
interface BlockingSuggestionProvider<C> extends SuggestionProvider<C> {

    /**
     * Returns the suggestions for the given {@code input}.
     *
     * <p>The {@code input} parameter contains all sender-provided input that has not yet been consumed by the argument parsers.
     * If the component that the suggestion provider is generating suggestions for consumes multiple tokens the suggestion
     * provider might receive a {@link CommandInput} instance containing multiple tokens.
     * {@link CommandInput#lastRemainingToken()} may be used to extract the part of the command that is currently being
     * completed by the command sender.</p>
     *
     * @param context the context of the suggestion lookup
     * @param input   the current input
     * @return the suggestions
     */
    @NonNull Iterable<? extends @NonNull Suggestion> suggestions(@NonNull CommandContext<C> context, @NonNull CommandInput input);

    @Override
    default @NonNull CompletableFuture<? extends @NonNull Iterable<? extends @NonNull Suggestion>> suggestionsFuture(
            final @NonNull CommandContext<C> context,
            final @NonNull CommandInput input
    ) {
        return CompletableFuture.completedFuture(this.suggestions(context, input));
    }

    /**
     * Specialized variant of {@link BlockingSuggestionProvider} that has {@link String} results
     * instead of {@link Suggestion} results.
     *
     * <p>The provided default implementation of {@link #suggestions(CommandContext, CommandInput)}
     * maps the {@link String} results to {@link Suggestion suggestions} using {@link Suggestion#suggestion(String)}.</p>
     *
     * @param <C> command sender type
     */
    @FunctionalInterface
    @API(status = API.Status.STABLE)
    interface Strings<C> extends BlockingSuggestionProvider<C> {

        /**
         * Returns the suggestions for the given {@code input}.
         *
         * <p>The {@code input} parameter contains all sender-provided input that has not yet been consumed by the argument parsers.
         * If the component that the suggestion provider is generating suggestions for consumes multiple tokens the suggestion
         * provider might receive a {@link CommandInput} instance containing multiple tokens.
         * {@link CommandInput#lastRemainingToken()} may be used to extract the part of the command that is currently being
         * completed by the command sender.</p>
         *
         * @param commandContext Command context
         * @param input          Input string
         * @return List of suggestions
         */
        @NonNull Iterable<@NonNull String> stringSuggestions(
                @NonNull CommandContext<C> commandContext,
                @NonNull CommandInput input
        );

        @Override
        default @NonNull Iterable<@NonNull Suggestion> suggestions(
                final @NonNull CommandContext<C> context,
                final @NonNull CommandInput input
        ) {
            return StreamSupport.stream(this.stringSuggestions(context, input).spliterator(), false)
                    .map(Suggestion::suggestion)
                    .collect(Collectors.toList());
        }
    }
}
