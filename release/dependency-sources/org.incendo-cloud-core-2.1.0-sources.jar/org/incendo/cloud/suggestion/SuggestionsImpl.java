//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.suggestion;

import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;
import org.incendo.cloud.context.CommandContext;
import org.incendo.cloud.context.CommandInput;

/**
 * Immutable implementation of {@link Suggestions}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code SuggestionsImpl.of()}.
 */
@Generated(from = "Suggestions", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class SuggestionsImpl<C, S extends Suggestion>
    implements Suggestions<C, S> {
  private final @NonNull CommandContext<C> commandContext;
  private final @NonNull List<S> list;
  private final @NonNull CommandInput commandInput;

  private SuggestionsImpl(
      @NonNull CommandContext<C> commandContext,
      Iterable<? extends S> list,
      @NonNull CommandInput commandInput) {
    this.commandContext = Objects.requireNonNull(commandContext, "commandContext");
    this.list = createUnmodifiableList(false, createSafeList(list, true, false));
    this.commandInput = Objects.requireNonNull(commandInput, "commandInput");
  }

  private SuggestionsImpl(
      SuggestionsImpl<C, S> original,
      @NonNull CommandContext<C> commandContext,
      @NonNull List<S> list,
      @NonNull CommandInput commandInput) {
    this.commandContext = commandContext;
    this.list = list;
    this.commandInput = commandInput;
  }

  /**
   * @return The value of the {@code commandContext} attribute
   */
  @Override
  public @NonNull CommandContext<C> commandContext() {
    return commandContext;
  }

  /**
   * @return The value of the {@code list} attribute
   */
  @Override
  public @NonNull List<S> list() {
    return list;
  }

  /**
   * @return The value of the {@code commandInput} attribute
   */
  @Override
  public @NonNull CommandInput commandInput() {
    return commandInput;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link Suggestions#commandContext() commandContext} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandContext
   * @return A modified copy or the {@code this} object
   */
  public final SuggestionsImpl<C, S> withCommandContext(@NonNull CommandContext<C> value) {
    if (this.commandContext == value) return this;
    @NonNull CommandContext<C> newValue = Objects.requireNonNull(value, "commandContext");
    return new SuggestionsImpl<>(this, newValue, this.list, this.commandInput);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link Suggestions#list() list}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  @SafeVarargs @SuppressWarnings("varargs")
  public final SuggestionsImpl<C, S> withList(S... elements) {
    @NonNull List<S> newValue = createUnmodifiableList(false, createSafeList(Arrays.asList(elements), true, false));
    return new SuggestionsImpl<>(this, this.commandContext, newValue, this.commandInput);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link Suggestions#list() list}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of list elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final SuggestionsImpl<C, S> withList(Iterable<? extends S> elements) {
    if (this.list == elements) return this;
    @NonNull List<S> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new SuggestionsImpl<>(this, this.commandContext, newValue, this.commandInput);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link Suggestions#commandInput() commandInput} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for commandInput
   * @return A modified copy or the {@code this} object
   */
  public final SuggestionsImpl<C, S> withCommandInput(@NonNull CommandInput value) {
    if (this.commandInput == value) return this;
    @NonNull CommandInput newValue = Objects.requireNonNull(value, "commandInput");
    return new SuggestionsImpl<>(this, this.commandContext, this.list, newValue);
  }

  /**
   * This instance is equal to all instances of {@code SuggestionsImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof SuggestionsImpl<?, ?>
        && equalsByValue((SuggestionsImpl<?, ?>) another);
  }

  private boolean equalsByValue(SuggestionsImpl<?, ?> another) {
    return commandContext.equals(another.commandContext)
        && list.equals(another.list)
        && commandInput.equals(another.commandInput);
  }

  /**
   * Computes a hash code from attributes: {@code commandContext}, {@code list}, {@code commandInput}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + commandContext.hashCode();
    h += (h << 5) + list.hashCode();
    h += (h << 5) + commandInput.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code Suggestions} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "Suggestions{"
        + "commandContext=" + commandContext
        + ", list=" + list
        + ", commandInput=" + commandInput
        + "}";
  }

  /**
   * Construct a new immutable {@code Suggestions} instance.
 * @param <C> generic parameter C
 * @param <S> generic parameter S
   * @param commandContext The value for the {@code commandContext} attribute
   * @param list The value for the {@code list} attribute
   * @param commandInput The value for the {@code commandInput} attribute
   * @return An immutable Suggestions instance
   */
  public static <C, S extends Suggestion> SuggestionsImpl<C, S> of(@NonNull CommandContext<C> commandContext, @NonNull List<S> list, @NonNull CommandInput commandInput) {
    return of(commandContext, (Iterable<? extends S>) list, commandInput);
  }

  /**
   * Construct a new immutable {@code Suggestions} instance.
 * @param <C> generic parameter C
 * @param <S> generic parameter S
   * @param commandContext The value for the {@code commandContext} attribute
   * @param list The value for the {@code list} attribute
   * @param commandInput The value for the {@code commandInput} attribute
   * @return An immutable Suggestions instance
   */
  public static <C, S extends Suggestion> SuggestionsImpl<C, S> of(@NonNull CommandContext<C> commandContext, Iterable<? extends S> list, @NonNull CommandInput commandInput) {
    return new SuggestionsImpl<>(commandContext, list, commandInput);
  }

  /**
   * Creates an immutable copy of a {@link Suggestions} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <C> generic parameter C
   * @param <S> generic parameter S
   * @param instance The instance to copy
   * @return A copied immutable Suggestions instance
   */
  public static <C, S extends Suggestion> SuggestionsImpl<C, S> copyOf(Suggestions<C, S> instance) {
    if (instance instanceof SuggestionsImpl<?, ?>) {
      return (SuggestionsImpl<C, S>) instance;
    }
    return SuggestionsImpl.<C, S>of(instance.commandContext(), instance.list(), instance.commandInput());
  }

  private static <T> List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    ArrayList<T> list;
    if (iterable instanceof Collection<?>) {
      int size = ((Collection<?>) iterable).size();
      if (size == 0) return Collections.emptyList();
      list = new ArrayList<>(size);
    } else {
      list = new ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> List<T> createUnmodifiableList(boolean clone, List<? extends T> list) {
    switch(list.size()) {
    case 0: return Collections.emptyList();
    case 1: return Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return Collections.unmodifiableList(new ArrayList<>(list));
      } else {
        if (list instanceof ArrayList<?>) {
          ((ArrayList<?>) list).trimToSize();
        }
        return Collections.unmodifiableList(list);
      }
    }
  }
}
