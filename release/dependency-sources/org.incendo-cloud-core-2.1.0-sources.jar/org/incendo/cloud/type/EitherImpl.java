//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type;

import com.google.errorprone.annotations.Var;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link Either}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code EitherImpl.of()}.
 */
@Generated(from = "Either", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class EitherImpl<U, V> implements Either<U, V> {
  private final @Nullable U primary;
  private final @Nullable V fallback;

  @SuppressWarnings("unchecked") // safe covariant cast
  private EitherImpl(Optional<? extends U> primary, Optional<? extends V> fallback) {
    this.primary = primary.orElse(null);
    this.fallback = fallback.orElse(null);
  }

  @SuppressWarnings("unchecked") // safe covariant cast
  private EitherImpl(@Nullable U primary, @Nullable V fallback) {
    this.primary = primary;
    this.fallback = fallback;
  }

  private EitherImpl(
      EitherImpl<U, V> original,
      @Nullable U primary,
      @Nullable V fallback) {
    this.primary = primary;
    this.fallback = fallback;
  }

  /**
   * @return The value of the {@code primary} attribute
   */
  @Override
  public @NonNull Optional<U> primary() {
    return Optional.ofNullable(primary);
  }

  /**
   * @return The value of the {@code fallback} attribute
   */
  @Override
  public @NonNull Optional<V> fallback() {
    return Optional.ofNullable(fallback);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link Either#primary() primary} attribute.
   * @param value The value for primary, {@code null} is accepted as {@code java.util.Optional.empty()}
   * @return A modified copy or {@code this} if not changed
   */
  public final EitherImpl<U, V> withPrimary(@Nullable U value) {
    @Nullable U newValue = value;
    if (this.primary == newValue) return this;
    return new EitherImpl<>(this, newValue, this.fallback);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link Either#primary() primary} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for primary
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final EitherImpl<U, V> withPrimary(Optional<? extends U> optional) {
    @Nullable U value = optional.orElse(null);
    if (this.primary == value) return this;
    return new EitherImpl<>(this, value, this.fallback);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link Either#fallback() fallback} attribute.
   * @param value The value for fallback, {@code null} is accepted as {@code java.util.Optional.empty()}
   * @return A modified copy or {@code this} if not changed
   */
  public final EitherImpl<U, V> withFallback(@Nullable V value) {
    @Nullable V newValue = value;
    if (this.fallback == newValue) return this;
    return new EitherImpl<>(this, this.primary, newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link Either#fallback() fallback} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for fallback
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final EitherImpl<U, V> withFallback(Optional<? extends V> optional) {
    @Nullable V value = optional.orElse(null);
    if (this.fallback == value) return this;
    return new EitherImpl<>(this, this.primary, value);
  }

  /**
   * This instance is equal to all instances of {@code EitherImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof EitherImpl<?, ?>
        && equalsByValue((EitherImpl<?, ?>) another);
  }

  private boolean equalsByValue(EitherImpl<?, ?> another) {
    return Objects.equals(primary, another.primary)
        && Objects.equals(fallback, another.fallback);
  }

  /**
   * Computes a hash code from attributes: {@code primary}, {@code fallback}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(primary);
    h += (h << 5) + Objects.hashCode(fallback);
    return h;
  }

  /**
   * Prints the immutable value {@code Either} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder("Either{");
    if (primary != null) {
      builder.append("primary=").append(primary);
    }
    if (fallback != null) {
      if (builder.length() > 7) builder.append(", ");
      builder.append("fallback=").append(fallback);
    }
    return builder.append("}").toString();
  }

  /**
   * Construct a new immutable {@code Either} instance.
 * @param <U> generic parameter U
 * @param <V> generic parameter V
   * @param primary The value for the {@code primary} attribute
   * @param fallback The value for the {@code fallback} attribute
   * @return An immutable Either instance
   */
  public static <U, V> EitherImpl<U, V> of(Optional<? extends U> primary, Optional<? extends V> fallback) {
    return new EitherImpl<>(primary, fallback);
  }

  /**
   * Construct a new immutable {@code Either} instance.
   * @param <U> generic parameter U
   * @param <V> generic parameter V
   * @param primary The value for the {@code primary} attribute
   * @param fallback The value for the {@code fallback} attribute
   * @return An immutable Either instance
   */
  public static <U, V> EitherImpl<U, V> of(@Nullable U primary, @Nullable V fallback) {
    return new EitherImpl<>(primary, fallback);
  }

  /**
   * Creates an immutable copy of a {@link Either} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param <U> generic parameter U
   * @param <V> generic parameter V
   * @param instance The instance to copy
   * @return A copied immutable Either instance
   */
  public static <U, V> EitherImpl<U, V> copyOf(Either<U, V> instance) {
    if (instance instanceof EitherImpl<?, ?>) {
      return (EitherImpl<U, V>) instance;
    }
    return EitherImpl.<U, V>of(instance.primary(), instance.fallback());
  }
}
