//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type.range;

import com.google.errorprone.annotations.Var;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ByteRange}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code ByteRangeImpl.of()}.
 */
@Generated(from = "ByteRange", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class ByteRangeImpl implements ByteRange {
  private final byte minByte;
  private final byte maxByte;

  private ByteRangeImpl(byte minByte, byte maxByte) {
    this.minByte = minByte;
    this.maxByte = maxByte;
  }

  /**
   * @return The value of the {@code minByte} attribute
   */
  @Override
  public byte minByte() {
    return minByte;
  }

  /**
   * @return The value of the {@code maxByte} attribute
   */
  @Override
  public byte maxByte() {
    return maxByte;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ByteRange#minByte() minByte} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for minByte
   * @return A modified copy or the {@code this} object
   */
  public final ByteRangeImpl withMinByte(byte value) {
    if (this.minByte == value) return this;
    return new ByteRangeImpl(value, this.maxByte);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ByteRange#maxByte() maxByte} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for maxByte
   * @return A modified copy or the {@code this} object
   */
  public final ByteRangeImpl withMaxByte(byte value) {
    if (this.maxByte == value) return this;
    return new ByteRangeImpl(this.minByte, value);
  }

  /**
   * This instance is equal to all instances of {@code ByteRangeImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ByteRangeImpl
        && equalsByValue((ByteRangeImpl) another);
  }

  private boolean equalsByValue(ByteRangeImpl another) {
    return minByte == another.minByte
        && maxByte == another.maxByte;
  }

  /**
   * Computes a hash code from attributes: {@code minByte}, {@code maxByte}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Byte.hashCode(minByte);
    h += (h << 5) + Byte.hashCode(maxByte);
    return h;
  }

  /**
   * Prints the immutable value {@code ByteRange} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ByteRange{"
        + "minByte=" + minByte
        + ", maxByte=" + maxByte
        + "}";
  }

  /**
   * Construct a new immutable {@code ByteRange} instance.
   * @param minByte The value for the {@code minByte} attribute
   * @param maxByte The value for the {@code maxByte} attribute
   * @return An immutable ByteRange instance
   */
  public static ByteRangeImpl of(byte minByte, byte maxByte) {
    return new ByteRangeImpl(minByte, maxByte);
  }

  /**
   * Creates an immutable copy of a {@link ByteRange} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ByteRange instance
   */
  public static ByteRangeImpl copyOf(ByteRange instance) {
    if (instance instanceof ByteRangeImpl) {
      return (ByteRangeImpl) instance;
    }
    return ByteRangeImpl.of(instance.minByte(), instance.maxByte());
  }
}
