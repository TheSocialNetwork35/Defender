//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type.range;

import com.google.errorprone.annotations.Var;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link DoubleRange}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code DoubleRangeImpl.of()}.
 */
@Generated(from = "DoubleRange", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class DoubleRangeImpl implements DoubleRange {
  private final double minDouble;
  private final double maxDouble;

  private DoubleRangeImpl(double minDouble, double maxDouble) {
    this.minDouble = minDouble;
    this.maxDouble = maxDouble;
  }

  /**
   * @return The value of the {@code minDouble} attribute
   */
  @Override
  public double minDouble() {
    return minDouble;
  }

  /**
   * @return The value of the {@code maxDouble} attribute
   */
  @Override
  public double maxDouble() {
    return maxDouble;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link DoubleRange#minDouble() minDouble} attribute.
   * A value strict bits equality used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for minDouble
   * @return A modified copy or the {@code this} object
   */
  public final DoubleRangeImpl withMinDouble(double value) {
    if (Double.doubleToLongBits(this.minDouble) == Double.doubleToLongBits(value)) return this;
    return new DoubleRangeImpl(value, this.maxDouble);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link DoubleRange#maxDouble() maxDouble} attribute.
   * A value strict bits equality used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for maxDouble
   * @return A modified copy or the {@code this} object
   */
  public final DoubleRangeImpl withMaxDouble(double value) {
    if (Double.doubleToLongBits(this.maxDouble) == Double.doubleToLongBits(value)) return this;
    return new DoubleRangeImpl(this.minDouble, value);
  }

  /**
   * This instance is equal to all instances of {@code DoubleRangeImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof DoubleRangeImpl
        && equalsByValue((DoubleRangeImpl) another);
  }

  private boolean equalsByValue(DoubleRangeImpl another) {
    return Double.doubleToLongBits(minDouble) == Double.doubleToLongBits(another.minDouble)
        && Double.doubleToLongBits(maxDouble) == Double.doubleToLongBits(another.maxDouble);
  }

  /**
   * Computes a hash code from attributes: {@code minDouble}, {@code maxDouble}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Double.hashCode(minDouble);
    h += (h << 5) + Double.hashCode(maxDouble);
    return h;
  }

  /**
   * Prints the immutable value {@code DoubleRange} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "DoubleRange{"
        + "minDouble=" + minDouble
        + ", maxDouble=" + maxDouble
        + "}";
  }

  /**
   * Construct a new immutable {@code DoubleRange} instance.
   * @param minDouble The value for the {@code minDouble} attribute
   * @param maxDouble The value for the {@code maxDouble} attribute
   * @return An immutable DoubleRange instance
   */
  public static DoubleRangeImpl of(double minDouble, double maxDouble) {
    return new DoubleRangeImpl(minDouble, maxDouble);
  }

  /**
   * Creates an immutable copy of a {@link DoubleRange} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable DoubleRange instance
   */
  public static DoubleRangeImpl copyOf(DoubleRange instance) {
    if (instance instanceof DoubleRangeImpl) {
      return (DoubleRangeImpl) instance;
    }
    return DoubleRangeImpl.of(instance.minDouble(), instance.maxDouble());
  }
}
