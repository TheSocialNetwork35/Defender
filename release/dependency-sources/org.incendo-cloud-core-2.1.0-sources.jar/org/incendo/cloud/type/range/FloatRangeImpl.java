//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type.range;

import com.google.errorprone.annotations.Var;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link FloatRange}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code FloatRangeImpl.of()}.
 */
@Generated(from = "FloatRange", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class FloatRangeImpl implements FloatRange {
  private final float minFloat;
  private final float maxFloat;

  private FloatRangeImpl(float minFloat, float maxFloat) {
    this.minFloat = minFloat;
    this.maxFloat = maxFloat;
  }

  /**
   * @return The value of the {@code minFloat} attribute
   */
  @Override
  public float minFloat() {
    return minFloat;
  }

  /**
   * @return The value of the {@code maxFloat} attribute
   */
  @Override
  public float maxFloat() {
    return maxFloat;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FloatRange#minFloat() minFloat} attribute.
   * A value strict bits equality used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for minFloat
   * @return A modified copy or the {@code this} object
   */
  public final FloatRangeImpl withMinFloat(float value) {
    if (Float.floatToIntBits(this.minFloat) == Float.floatToIntBits(value)) return this;
    return new FloatRangeImpl(value, this.maxFloat);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link FloatRange#maxFloat() maxFloat} attribute.
   * A value strict bits equality used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for maxFloat
   * @return A modified copy or the {@code this} object
   */
  public final FloatRangeImpl withMaxFloat(float value) {
    if (Float.floatToIntBits(this.maxFloat) == Float.floatToIntBits(value)) return this;
    return new FloatRangeImpl(this.minFloat, value);
  }

  /**
   * This instance is equal to all instances of {@code FloatRangeImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof FloatRangeImpl
        && equalsByValue((FloatRangeImpl) another);
  }

  private boolean equalsByValue(FloatRangeImpl another) {
    return Float.floatToIntBits(minFloat) == Float.floatToIntBits(another.minFloat)
        && Float.floatToIntBits(maxFloat) == Float.floatToIntBits(another.maxFloat);
  }

  /**
   * Computes a hash code from attributes: {@code minFloat}, {@code maxFloat}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Float.hashCode(minFloat);
    h += (h << 5) + Float.hashCode(maxFloat);
    return h;
  }

  /**
   * Prints the immutable value {@code FloatRange} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "FloatRange{"
        + "minFloat=" + minFloat
        + ", maxFloat=" + maxFloat
        + "}";
  }

  /**
   * Construct a new immutable {@code FloatRange} instance.
   * @param minFloat The value for the {@code minFloat} attribute
   * @param maxFloat The value for the {@code maxFloat} attribute
   * @return An immutable FloatRange instance
   */
  public static FloatRangeImpl of(float minFloat, float maxFloat) {
    return new FloatRangeImpl(minFloat, maxFloat);
  }

  /**
   * Creates an immutable copy of a {@link FloatRange} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable FloatRange instance
   */
  public static FloatRangeImpl copyOf(FloatRange instance) {
    if (instance instanceof FloatRangeImpl) {
      return (FloatRangeImpl) instance;
    }
    return FloatRangeImpl.of(instance.minFloat(), instance.maxFloat());
  }
}
