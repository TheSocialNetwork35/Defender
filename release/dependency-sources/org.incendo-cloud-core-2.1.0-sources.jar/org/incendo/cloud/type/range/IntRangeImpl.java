//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type.range;

import com.google.errorprone.annotations.Var;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link IntRange}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code IntRangeImpl.of()}.
 */
@Generated(from = "IntRange", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class IntRangeImpl implements IntRange {
  private final int minInt;
  private final int maxInt;

  private IntRangeImpl(int minInt, int maxInt) {
    this.minInt = minInt;
    this.maxInt = maxInt;
  }

  /**
   * @return The value of the {@code minInt} attribute
   */
  @Override
  public int minInt() {
    return minInt;
  }

  /**
   * @return The value of the {@code maxInt} attribute
   */
  @Override
  public int maxInt() {
    return maxInt;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link IntRange#minInt() minInt} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for minInt
   * @return A modified copy or the {@code this} object
   */
  public final IntRangeImpl withMinInt(int value) {
    if (this.minInt == value) return this;
    return new IntRangeImpl(value, this.maxInt);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link IntRange#maxInt() maxInt} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for maxInt
   * @return A modified copy or the {@code this} object
   */
  public final IntRangeImpl withMaxInt(int value) {
    if (this.maxInt == value) return this;
    return new IntRangeImpl(this.minInt, value);
  }

  /**
   * This instance is equal to all instances of {@code IntRangeImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof IntRangeImpl
        && equalsByValue((IntRangeImpl) another);
  }

  private boolean equalsByValue(IntRangeImpl another) {
    return minInt == another.minInt
        && maxInt == another.maxInt;
  }

  /**
   * Computes a hash code from attributes: {@code minInt}, {@code maxInt}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + minInt;
    h += (h << 5) + maxInt;
    return h;
  }

  /**
   * Prints the immutable value {@code IntRange} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "IntRange{"
        + "minInt=" + minInt
        + ", maxInt=" + maxInt
        + "}";
  }

  /**
   * Construct a new immutable {@code IntRange} instance.
   * @param minInt The value for the {@code minInt} attribute
   * @param maxInt The value for the {@code maxInt} attribute
   * @return An immutable IntRange instance
   */
  public static IntRangeImpl of(int minInt, int maxInt) {
    return new IntRangeImpl(minInt, maxInt);
  }

  /**
   * Creates an immutable copy of a {@link IntRange} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable IntRange instance
   */
  public static IntRangeImpl copyOf(IntRange instance) {
    if (instance instanceof IntRangeImpl) {
      return (IntRangeImpl) instance;
    }
    return IntRangeImpl.of(instance.minInt(), instance.maxInt());
  }
}
