//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type.range;

import com.google.errorprone.annotations.Var;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link LongRange}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code LongRangeImpl.of()}.
 */
@Generated(from = "LongRange", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class LongRangeImpl implements LongRange {
  private final long minLong;
  private final long maxLong;

  private LongRangeImpl(long minLong, long maxLong) {
    this.minLong = minLong;
    this.maxLong = maxLong;
  }

  /**
   * @return The value of the {@code minLong} attribute
   */
  @Override
  public long minLong() {
    return minLong;
  }

  /**
   * @return The value of the {@code maxLong} attribute
   */
  @Override
  public long maxLong() {
    return maxLong;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link LongRange#minLong() minLong} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for minLong
   * @return A modified copy or the {@code this} object
   */
  public final LongRangeImpl withMinLong(long value) {
    if (this.minLong == value) return this;
    return new LongRangeImpl(value, this.maxLong);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link LongRange#maxLong() maxLong} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for maxLong
   * @return A modified copy or the {@code this} object
   */
  public final LongRangeImpl withMaxLong(long value) {
    if (this.maxLong == value) return this;
    return new LongRangeImpl(this.minLong, value);
  }

  /**
   * This instance is equal to all instances of {@code LongRangeImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof LongRangeImpl
        && equalsByValue((LongRangeImpl) another);
  }

  private boolean equalsByValue(LongRangeImpl another) {
    return minLong == another.minLong
        && maxLong == another.maxLong;
  }

  /**
   * Computes a hash code from attributes: {@code minLong}, {@code maxLong}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Long.hashCode(minLong);
    h += (h << 5) + Long.hashCode(maxLong);
    return h;
  }

  /**
   * Prints the immutable value {@code LongRange} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "LongRange{"
        + "minLong=" + minLong
        + ", maxLong=" + maxLong
        + "}";
  }

  /**
   * Construct a new immutable {@code LongRange} instance.
   * @param minLong The value for the {@code minLong} attribute
   * @param maxLong The value for the {@code maxLong} attribute
   * @return An immutable LongRange instance
   */
  public static LongRangeImpl of(long minLong, long maxLong) {
    return new LongRangeImpl(minLong, maxLong);
  }

  /**
   * Creates an immutable copy of a {@link LongRange} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable LongRange instance
   */
  public static LongRangeImpl copyOf(LongRange instance) {
    if (instance instanceof LongRangeImpl) {
      return (LongRangeImpl) instance;
    }
    return LongRangeImpl.of(instance.minLong(), instance.maxLong());
  }
}
