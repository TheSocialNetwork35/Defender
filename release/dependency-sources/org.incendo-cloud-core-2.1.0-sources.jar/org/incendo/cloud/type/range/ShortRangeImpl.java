//
// MIT License
//
// Copyright (c) 2024 Incendo
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
package org.incendo.cloud.type.range;

import com.google.errorprone.annotations.Var;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.apiguardian.api.API;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ShortRange}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code ShortRangeImpl.of()}.
 */
@Generated(from = "ShortRange", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
@API(status = API.Status.INTERNAL, consumers = "org.incendo.cloud.*")
final class ShortRangeImpl implements ShortRange {
  private final short minShort;
  private final short maxShort;

  private ShortRangeImpl(short minShort, short maxShort) {
    this.minShort = minShort;
    this.maxShort = maxShort;
  }

  /**
   * @return The value of the {@code minShort} attribute
   */
  @Override
  public short minShort() {
    return minShort;
  }

  /**
   * @return The value of the {@code maxShort} attribute
   */
  @Override
  public short maxShort() {
    return maxShort;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ShortRange#minShort() minShort} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for minShort
   * @return A modified copy or the {@code this} object
   */
  public final ShortRangeImpl withMinShort(short value) {
    if (this.minShort == value) return this;
    return new ShortRangeImpl(value, this.maxShort);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ShortRange#maxShort() maxShort} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for maxShort
   * @return A modified copy or the {@code this} object
   */
  public final ShortRangeImpl withMaxShort(short value) {
    if (this.maxShort == value) return this;
    return new ShortRangeImpl(this.minShort, value);
  }

  /**
   * This instance is equal to all instances of {@code ShortRangeImpl} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ShortRangeImpl
        && equalsByValue((ShortRangeImpl) another);
  }

  private boolean equalsByValue(ShortRangeImpl another) {
    return minShort == another.minShort
        && maxShort == another.maxShort;
  }

  /**
   * Computes a hash code from attributes: {@code minShort}, {@code maxShort}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Short.hashCode(minShort);
    h += (h << 5) + Short.hashCode(maxShort);
    return h;
  }

  /**
   * Prints the immutable value {@code ShortRange} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return "ShortRange{"
        + "minShort=" + minShort
        + ", maxShort=" + maxShort
        + "}";
  }

  /**
   * Construct a new immutable {@code ShortRange} instance.
   * @param minShort The value for the {@code minShort} attribute
   * @param maxShort The value for the {@code maxShort} attribute
   * @return An immutable ShortRange instance
   */
  public static ShortRangeImpl of(short minShort, short maxShort) {
    return new ShortRangeImpl(minShort, maxShort);
  }

  /**
   * Creates an immutable copy of a {@link ShortRange} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ShortRange instance
   */
  public static ShortRangeImpl copyOf(ShortRange instance) {
    if (instance instanceof ShortRangeImpl) {
      return (ShortRangeImpl) instance;
    }
    return ShortRangeImpl.of(instance.minShort(), instance.maxShort());
  }
}
